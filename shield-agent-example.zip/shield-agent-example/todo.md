# kks-next TODO

Last updated: 2026-05-08.

## Current judgment

`kks-next` is ready for internal testing and internal reporting.
It is not yet ready for old-KKS replacement or production cutover.

## Already done

- Three-layer architecture is stable: `kks_runtime` / `kks_security` / `kks_surfaces`
- Main graph is stable:
  - `asset_resolution`
  - `supervisor`
  - `log_detective`
  - `machine_check`
  - `security_guard`
  - `causality_judge`
  - `strategy_mapper`
  - `approval_gate`
  - `reporter`
- WLL-style structured evidence is implemented on log side and machine side
- Investigation-layer typed findings are in place
- Strategy/action mapping is in place
- Report schema now carries explicit investigation-layer contract fields:
  - abnormal object
  - status/source attribution
  - temporal relation
  - classification
  - evidence tags
  - recommended action titles
  - mitigation rationale
- Degraded runtime and degraded report path are explicit and tested
- Alert window normalization is in place
- Empty-result early-stop is in place
- Grafana webhook -> investigation -> Feishu robot delivery is active
- Feishu alert/chat bitable persistence is active
- `context.md` replay assets are registered and graded
- WLL fixture set now drives case-eval assertions across causality, strategy, report contract, and Feishu surface rendering

## Remaining for v1

These items still block the claim that `v1` is complete.

### 1. Report contract tightening

- [ ] Add a compact AI mistake review section for replay/eval use
- [ ] Review final report prose quality on replay cases now that explicit contract fields are in schema

### 2. Replay asset completion

- [x] Convert Wang Longlong's text/PDF set into structured replay fixtures
- [x] Store per case:
  - target
  - alert type
  - final classification
  - status origin
  - temporal relation
  - key evidence tags
  - expected mitigation strategy
  - historical AI failure reasons
- [ ] Gate further runtime tuning on replay correctness
- [x] Promote the WLL fixture set from inventory-only into replay/case-eval assertions

### 3. Runtime support closure

- [ ] Audit `Any`-typed evidence/report fields and tighten them where practical
- [ ] Add per-investigation ES cache
- [ ] Ensure cache key includes tool name + normalized args + source selector
- [ ] Keep cache scope at one investigation/session only
- [ ] Surface cache hits in tracing for auditability

## Rollout gates

These items block old-KKS replacement and production cutover.

### Replay gate

- [ ] Recorded replay passes on the expanded WLL fixture set
- [ ] Source attribution is correct on domain `4xx/5xx` cases
- [ ] Attack vs non-attack classification is reviewed case by case
- [ ] No silent degradation in report output

### Shadow gate

- [ ] Run live shadow stream beside old KKS
- [ ] No unhandled runtime exceptions in shadow mode
- [ ] Write old-KKS vs `kks-next` comparison rubric
- [ ] Review parity incident by incident
- [ ] Define rollback trigger conditions
- [ ] Define signoff owner for replay parity, shadow parity, and canary expansion

### Canary gate

- [ ] Stage 1: 5% of one production-facing surface
- [ ] Stage 2: 25% after one stable observation window
- [ ] Stage 3: 100% only after parity review and rollback signoff

## Current scope boundary

Must already be true for this line of work:

- attack / non-attack conclusions depend on typed evidence
- source attribution for domain `4xx/5xx` incidents is code-driven
- temporal causality is code-driven
- node-pressure attack judgment can use machine + log evidence
- runtime output is JSON-safe and replay-stable

Must still stay out of scope for this phase:

- no unbounded autonomous planning
- no default direct production remediation
- no production cutover before replay + shadow parity

## P2 deferred

These items are valid, but they must not block internal testing or `v1` closure.

- [ ] Feishu card template with stronger structured presentation
- [ ] Full old-KKS Feishu parity beyond current alert/chat persistence
- [ ] Grafana chart rendering and Feishu image upload
- [ ] Strengthen `InvestigationArtifact.report` into a broader stable UI contract
- [ ] Add more ES tools only when replay evidence proves the need

## Short directive

Keep the runtime graph bounded, typed, and auditable.

Do not reopen architecture shape unless replay or shadow evidence proves a real defect.
