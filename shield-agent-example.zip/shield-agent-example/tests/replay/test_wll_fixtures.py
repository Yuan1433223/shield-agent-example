from __future__ import annotations

import json
import shutil
import subprocess
import sys
import uuid
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[2]
FIXTURE_ROOT = REPO_ROOT / "tests" / "replay" / "wll_fixtures"
SOURCE_ROOT = REPO_ROOT / "docs" / "experts" / "WLL"
SCRIPT_PATH = REPO_ROOT / "scripts" / "build_wll_fixtures.py"


def test_committed_wll_fixture_inventory_is_complete():
    index_path = FIXTURE_ROOT / "index.json"
    assert index_path.exists()

    index = json.loads(index_path.read_text(encoding="utf-8"))
    fixture_files = sorted(path for path in FIXTURE_ROOT.glob("*.json") if path.name != "index.json")
    source_files = sorted(SOURCE_ROOT.rglob("*.txt"))

    assert index["case_count"] == len(source_files) == len(fixture_files)
    assert index["classification_counts"] == {"attack": 10, "non_attack": 9}

    required_fields = {
        "case_id",
        "operator",
        "source_file",
        "target",
        "target_type",
        "alert_time",
        "final_classification",
        "attack_type",
        "status_origin",
        "temporal_relation",
        "evidence_tags",
        "investigation_steps",
        "mitigation_actions",
        "sections",
    }

    for path in fixture_files:
        payload = json.loads(path.read_text(encoding="utf-8"))
        assert required_fields.issubset(payload)
        assert payload["operator"] == "wang_longlong"
        assert payload["final_classification"] in {"attack", "non_attack"}
        assert payload["target_type"] in {"domain", "ip"}
        assert isinstance(payload["evidence_tags"], list)
        assert isinstance(payload["sections"], dict)
        assert payload["sections"]["conclusion"]


def test_wll_fixture_builder_cli_rebuilds_inventory():
    tmp_path = REPO_ROOT / ".tmp_wll_fixture_build" / uuid.uuid4().hex
    tmp_path.parent.mkdir(parents=True, exist_ok=True)
    result = subprocess.run(
        [sys.executable, str(SCRIPT_PATH), "--src", str(SOURCE_ROOT), "--dst", str(tmp_path)],
        cwd=REPO_ROOT,
        check=False,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stderr

    index = json.loads((tmp_path / "index.json").read_text(encoding="utf-8"))
    assert index["case_count"] == 19
    assert index["classification_counts"] == {"attack": 10, "non_attack": 9}
    assert "request_spike" in index["evidence_tag_counts"]
    shutil.rmtree(tmp_path, ignore_errors=True)
