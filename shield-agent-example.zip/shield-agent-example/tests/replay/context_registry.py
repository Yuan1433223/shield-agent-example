"""Replay fixture registry derived from curated incidents in context.md."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

ReplayGrade = Literal[
    "replay_ready_raw",
    "replay_ready_partial",
    "gold_only",
    "pending_evidence",
]


@dataclass(frozen=True)
class ReplayCaseStatus:
    """Status metadata for one context-derived replay asset."""

    case_id: str
    target: str
    alert_name: str
    source_ref: str
    grade: ReplayGrade
    has_gold_report: bool
    has_structured_findings: bool
    raw_alert_payload_available: bool
    raw_tool_snapshot_available: bool
    notes: str = ""
    missing_fields: tuple[str, ...] = field(default_factory=tuple)


RECORDED_CONTEXT_REPLAY_CASES: tuple[ReplayCaseStatus, ...] = (
    ReplayCaseStatus(
        case_id="game_ali213_4xx",
        target="game.ali213.net",
        alert_name="domain 1min aggregated 4xx trend +1000%",
        source_ref="context.md#1",
        grade="replay_ready_partial",
        has_gold_report=True,
        has_structured_findings=True,
        raw_alert_payload_available=False,
        raw_tool_snapshot_available=False,
        notes=(
            "Recorded production domain incident from context.md. "
            "Replay assertions exist, but only from curated operator material."
        ),
    ),
    ReplayCaseStatus(
        case_id="api2_xs2027_5xx",
        target="api2.xs2027.cn",
        alert_name="domain 1min aggregated 5xx trend +600%",
        source_ref="context.md#2",
        grade="replay_ready_partial",
        has_gold_report=True,
        has_structured_findings=True,
        raw_alert_payload_available=False,
        raw_tool_snapshot_available=False,
        notes=(
            "Recorded production domain incident from context.md. "
            "Replay assertions exist, but raw webhook/tool snapshots were not preserved."
        ),
    ),
    ReplayCaseStatus(
        case_id="kk331_5xx_absolute",
        target="kk331dsdi32onew.liu6t.cn",
        alert_name="domain 1min aggregated 5xx absolute threshold exceeded",
        source_ref="context.md#3",
        grade="replay_ready_partial",
        has_gold_report=True,
        has_structured_findings=True,
        raw_alert_payload_available=False,
        raw_tool_snapshot_available=False,
        notes=(
            "Recorded production domain incident from context.md. "
            "Usable for replay/eval, but not a raw full-chain forensic snapshot."
        ),
    ),
)


PENDING_CONTEXT_REPLAY_CASES: tuple[ReplayCaseStatus, ...] = (
    ReplayCaseStatus(
        case_id="123_129_224_58_cpu_threshold",
        target="123.129.224.58",
        alert_name="high-defense node 5min average CPU threshold exceeded",
        source_ref="context.md#4",
        grade="pending_evidence",
        has_gold_report=False,
        has_structured_findings=False,
        raw_alert_payload_available=False,
        raw_tool_snapshot_available=False,
        notes=(
            "Real machine-side incident seed from context.md. "
            "Analysis result is empty, so it must not be treated as replay-ready yet."
        ),
        missing_fields=(
            "gold_report",
            "structured_findings",
            "machine_evidence_snapshot",
            "final_classification",
        ),
    ),
)
