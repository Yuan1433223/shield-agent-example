from tests.replay.context_registry import (
    PENDING_CONTEXT_REPLAY_CASES,
    RECORDED_CONTEXT_REPLAY_CASES,
)


def test_context_registry_records_three_partial_replay_ready_domain_cases():
    assert len(RECORDED_CONTEXT_REPLAY_CASES) == 3
    for case in RECORDED_CONTEXT_REPLAY_CASES:
        assert case.grade == "replay_ready_partial"
        assert case.has_gold_report is True
        assert case.has_structured_findings is True
        assert case.raw_alert_payload_available is False
        assert case.raw_tool_snapshot_available is False


def test_context_registry_marks_machine_case_as_pending_evidence():
    assert len(PENDING_CONTEXT_REPLAY_CASES) == 1
    case = PENDING_CONTEXT_REPLAY_CASES[0]
    assert case.target == "123.129.224.58"
    assert case.grade == "pending_evidence"
    assert case.has_gold_report is False
    assert case.has_structured_findings is False
    assert "machine_evidence_snapshot" in case.missing_fields


def test_pending_context_cases_are_not_mixed_into_replay_ready_inventory():
    recorded_ids = {case.case_id for case in RECORDED_CONTEXT_REPLAY_CASES}
    pending_ids = {case.case_id for case in PENDING_CONTEXT_REPLAY_CASES}
    assert recorded_ids.isdisjoint(pending_ids)
