from __future__ import annotations

import json
from pathlib import Path, PurePosixPath

from kks_security.policies.causality import CausalityPolicy
from kks_security.policies.strategy import StrategyMapperPolicy


REPO_ROOT = Path(__file__).resolve().parents[2]
FIXTURE_ROOT = REPO_ROOT / "tests" / "replay" / "wll_fixtures"


def load_wll_cases() -> list[dict]:
    cases: list[dict] = []
    for path in sorted(FIXTURE_ROOT.glob("*.json")):
        if path.name == "index.json":
            continue
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["_fixture_path"] = path.name
        cases.append(payload)
    return cases


def tag_set(case: dict) -> set[str]:
    return {str(tag) for tag in case.get("evidence_tags", [])}


def targeted_directories(paths: list[str]) -> list[str]:
    directories: list[str] = []
    for path in paths:
        parent = PurePosixPath(path).parent.as_posix()
        if parent not in {".", "/"} and parent not in directories:
            directories.append(parent)
    return directories


def project_status_origin(case: dict) -> str:
    raw = str(case.get("status_origin") or "")
    tags = tag_set(case)

    if case["final_classification"] == "non_attack" and (
        raw == "origin"
        or any(tag.startswith("origin_") for tag in tags)
        or "源站异常" in tags
    ):
        return "origin"
    if raw.startswith("mixed"):
        return "mixed"
    if raw.startswith("edge"):
        return "edge"
    if raw == "origin":
        return "origin"
    return "unknown"


def project_logs(case: dict) -> dict:
    tags = tag_set(case)
    paths = list(case.get("targeted_paths") or [])
    if case["final_classification"] != "attack" and "targeted_resource" not in tags:
        paths = []

    logs = {
        "summary": case.get("classification_reason") or case["sections"]["conclusion"],
        "risk_level": "high" if case["final_classification"] == "attack" else "medium",
        "status_origin": project_status_origin(case),
        "targeted_paths": paths,
        "targeted_directories": targeted_directories(paths),
        "origin_status_codes": [],
        "edge_status_codes": [],
        "ip_growth_signals": [],
        "ua_anomalies": [],
        "header_anomalies": [],
    }

    if "origin_4xx" in tags:
        logs["origin_status_codes"].append(404)
    if "origin_502" in tags:
        logs["origin_status_codes"].append(502)
    if "origin_503" in tags:
        logs["origin_status_codes"].append(503)
    if "edge_499" in tags:
        logs["edge_status_codes"].append(499)

    if "single_path_focus" in tags:
        logs["single_ip_single_url_burst"] = True
    if any(tag in tags for tag in {"ua_rotation", "ua_spoofing", "UA伪造", "UA变换"}):
        logs["ua_anomalies"] = ["dominant abnormal ua"]
    if any(tag in tags for tag in {"abnormal_header", "异常请求头部值", "请求语法错误"}):
        logs["header_anomalies"] = ["suspicious request header"]
    if any(
        tag in tags
        for tag in {
            "request_spike",
            "request_drop",
            "请求激增",
            "请求量掉坑",
            "高频请求",
            "攻击节点",
            "节点连接数突增",
        }
    ):
        logs["ip_growth_signals"] = ["abnormal client-side concentration"]

    if case["final_classification"] == "non_attack" and logs["status_origin"] == "origin":
        logs["error_before_traffic"] = True
        if "edge_499" in tags or "request_drop" in tags:
            logs["retry_pattern_suspected"] = True
    elif case["final_classification"] == "attack" and (
        "request_spike" in tags or "request_drop" in tags or "请求激增" in tags
    ):
        logs["traffic_before_error"] = True

    return logs


def project_machine(case: dict) -> dict:
    tags = tag_set(case)
    machine: dict = {}

    if any(
        tag in tags
        for tag in {"节点连接数突增", "节点CPU跑高", "攻击节点", "request_drop", "请求量掉坑"}
    ):
        machine = {
            "summary": case.get("classification_reason") or case["sections"]["conclusion"],
            "risk_level": "high" if case["final_classification"] == "attack" else "medium",
        }
        if "节点连接数突增" in tags:
            machine["connection_spike"] = True
        if "请求量掉坑" in tags or "request_drop" in tags:
            machine["request_hole"] = True
        if "节点CPU跑高" in tags:
            machine["response_time_spike"] = True
        if "攻击节点" in tags and "connection_spike" not in machine:
            machine["connection_spike"] = True
    return machine


def project_security(case: dict) -> dict:
    tags = tag_set(case)
    if any(tag in tags for tag in {"attack_blocked", "regional_blocking", "overseas_sources"}):
        return {
            "summary": case.get("classification_reason") or case["sections"]["conclusion"],
            "risk_level": "high",
            "cc_is_under_attack": True,
        }
    return {}


def project_case(case: dict) -> tuple[dict, dict, dict]:
    return project_logs(case), project_machine(case), project_security(case)


def evaluate_case(case: dict) -> tuple[dict, dict]:
    causality = CausalityPolicy()
    strategy_policy = StrategyMapperPolicy()
    logs, machine, security = project_case(case)

    investigation = causality.evaluate(
        logs=logs,
        machine=machine,
        security=security,
        abnormal_object=None,
    ).model_dump(mode="json")
    strategy = strategy_policy.map(investigation, target=case["target"]).model_dump(mode="json")
    return investigation, strategy
