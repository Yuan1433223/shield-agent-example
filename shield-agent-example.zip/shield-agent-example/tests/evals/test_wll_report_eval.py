from __future__ import annotations

from kks_runtime.artifacts.investigation import InvestigationArtifact
from kks_runtime.graph.nodes.reporter import (
    _derive_risk_level,
    _parse_recommendations,
    _stabilize_report_contract,
)
from kks_security.schemas.report import InvestigationReport
from kks_surfaces.feishu.delivery import report_to_feishu_payload
from tests.evals.wll_eval_support import evaluate_case, load_wll_cases


_WLL_CASES = load_wll_cases()


def _seed_report(case: dict) -> InvestigationReport:
    mitigation_text = "\n".join(case.get("mitigation_actions") or []) or "[requires analysis]"
    return InvestigationReport(
        alert_status="critical" if case["final_classification"] == "attack" else "warning",
        summary=case.get("classification_reason") or case["sections"]["conclusion"],
        recommendations=mitigation_text,
        root_cause=case["sections"]["conclusion"] or case.get("classification_reason"),
    )


def test_wll_cases_stabilize_report_contract_for_surface_use():
    for case in _WLL_CASES:
        investigation, strategy = evaluate_case(case)
        report = _seed_report(case)

        stabilized = _stabilize_report_contract(
            report,
            findings={"investigation": investigation, "strategy": strategy},
            degraded=False,
        )

        assert stabilized.classification == investigation["classification"], case["_fixture_path"]
        assert stabilized.status_origin == investigation["status_origin"], case["_fixture_path"]
        assert stabilized.temporal_relation == investigation["temporal_relation"], case["_fixture_path"]
        assert stabilized.evidence_tags == investigation["evidence_tags"], case["_fixture_path"]
        assert stabilized.recommended_action_titles == [
            action["title"] for action in strategy["recommended_actions"]
        ], case["_fixture_path"]
        assert stabilized.mitigation_rationale not in {None, "", "[requires analysis]"}, case["_fixture_path"]

        if investigation.get("abnormal_object"):
            assert stabilized.abnormal_object == investigation["abnormal_object"], case["_fixture_path"]


def test_wll_cases_surface_artifact_and_feishu_payload_keep_investigation_fields():
    for case in _WLL_CASES:
        investigation, strategy = evaluate_case(case)
        report = _seed_report(case)
        stabilized = _stabilize_report_contract(
            report,
            findings={"investigation": investigation, "strategy": strategy},
            degraded=False,
        )

        artifact = InvestigationArtifact(
            session_id=f"wll-{case['case_id']}",
            target=case["target"],
            findings={"investigation": investigation, "strategy": strategy},
            report=stabilized.model_dump(mode="json"),
            risk_level=_derive_risk_level(stabilized),
            summary=stabilized.summary or "Investigation complete.",
            recommendations=_parse_recommendations(stabilized.recommendations),
        )
        dumped = artifact.model_dump(mode="json")
        assert dumped["report"]["classification"] == investigation["classification"], case["_fixture_path"]
        assert dumped["report"]["status_origin"] == investigation["status_origin"], case["_fixture_path"]
        assert dumped["report"]["recommended_action_titles"], case["_fixture_path"]

        payload = report_to_feishu_payload(stabilized, case["target"])
        body = payload["card"]["elements"][0]["content"]
        assert "**Investigation**" in body, case["_fixture_path"]
        assert f"Classification: {investigation['classification']}" in body, case["_fixture_path"]
        if stabilized.abnormal_object:
            assert f"Object: {stabilized.abnormal_object}" in body, case["_fixture_path"]
        if stabilized.evidence_tags:
            assert "Evidence Tags:" in body, case["_fixture_path"]
