import pytest

from kks_security.policies.causality import CausalityPolicy
from kks_security.policies.strategy import StrategyMapperPolicy
from tests.evals.wll_eval_support import load_wll_cases, project_case, tag_set


_WLL_CASES = load_wll_cases()


@pytest.mark.parametrize("case", _WLL_CASES, ids=[case["case_id"] for case in _WLL_CASES])
def test_wll_cases_project_into_expected_causality_classification(case):
    policy = CausalityPolicy()
    logs, machine, security = project_case(case)

    result = policy.evaluate(
        logs=logs,
        machine=machine,
        security=security,
        abnormal_object=None,
    )

    assert result.classification == case["final_classification"], case["_fixture_path"]

    if case["final_classification"] == "attack":
        assert result.likely_cause in {
            "targeted_cc_attack",
            "edge_absorbed_attack",
            "node_pressure_attack",
        }, case["_fixture_path"]
    else:
        assert result.likely_cause in {
            "origin_generated_fault",
            "origin_fault_with_client_retry",
        }, case["_fixture_path"]

    if logs.get("targeted_paths"):
        assert result.abnormal_object == logs["targeted_paths"][0], case["_fixture_path"]
        assert "targeted_path" in result.evidence_tags, case["_fixture_path"]

    tags = tag_set(case)
    if any(tag in tags for tag in {"ua_rotation", "ua_spoofing", "UA伪造", "UA变换"}):
        assert "ua_anomaly" in result.evidence_tags, case["_fixture_path"]
    if any(tag in tags for tag in {"abnormal_header", "异常请求头部值", "请求语法错误"}):
        assert "header_anomaly" in result.evidence_tags, case["_fixture_path"]
    if any(tag in tags for tag in {"节点连接数突增", "节点CPU跑高", "攻击节点", "request_drop", "请求量掉坑"}):
        assert (
            {"connection_spike", "request_hole", "response_time_spike"} & set(result.evidence_tags)
        ), case["_fixture_path"]


@pytest.mark.parametrize("case", _WLL_CASES, ids=[case["case_id"] for case in _WLL_CASES])
def test_wll_cases_project_into_expected_strategy_actions(case):
    causality = CausalityPolicy()
    strategy_policy = StrategyMapperPolicy()
    logs, machine, security = project_case(case)

    investigation = causality.evaluate(
        logs=logs,
        machine=machine,
        security=security,
        abnormal_object=None,
    ).model_dump(mode="json")
    strategy = strategy_policy.map(investigation, target=case["target"])
    action_types = {action.action_type for action in strategy.recommended_actions}
    tags = tag_set(case)

    if case["final_classification"] == "non_attack":
        assert "customer_origin_check" in action_types, case["_fixture_path"]
    else:
        if any(tag in tags for tag in {"节点连接数突增", "节点CPU跑高", "攻击节点", "request_drop", "请求量掉坑"}):
            assert "block_top_offending_ips" in action_types, case["_fixture_path"]
        else:
            assert "enable_cc_defense_mode" in action_types, case["_fixture_path"]
        if case.get("targeted_paths"):
            assert "url_rate_limit" in action_types, case["_fixture_path"]
        if any(tag in tags for tag in {"ua_rotation", "ua_spoofing", "UA伪造", "UA变换"}):
            assert "ua_block_rule" in action_types, case["_fixture_path"]
        if any(tag in tags for tag in {"abnormal_header", "异常请求头部值", "请求语法错误"}):
            assert "header_block_rule" in action_types, case["_fixture_path"]
        if any(tag in tags for tag in {"request_spike", "request_drop", "高频请求", "攻击节点", "节点连接数突增"}):
            assert "block_top_offending_ips" in action_types, case["_fixture_path"]
