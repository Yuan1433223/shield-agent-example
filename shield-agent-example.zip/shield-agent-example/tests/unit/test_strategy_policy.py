from kks_security.policies.strategy import StrategyMapperPolicy


def test_strategy_policy_maps_attack_tags_to_actions():
    policy = StrategyMapperPolicy()
    result = policy.map(
        {
            "risk_level": "critical",
            "likely_cause": "targeted_cc_attack",
            "abnormal_object": "/api/trade/create",
            "mitigation_tags": ["url_rate_limit", "ip_block_or_cap", "header_block"],
        },
        target="example.com",
    )
    assert result.risk_level == "critical"
    assert result.execution_mode == "dry_run_only"
    action_types = {action.action_type for action in result.recommended_actions}
    assert "url_rate_limit" in action_types
    assert "block_top_offending_ips" in action_types
    assert "header_block_rule" in action_types


def test_strategy_policy_maps_origin_issue_to_manual_followup():
    policy = StrategyMapperPolicy()
    result = policy.map(
        {
            "risk_level": "medium",
            "likely_cause": "origin_fault_with_client_retry",
            "mitigation_tags": ["customer_origin_check"],
        },
        target="example.com",
    )
    assert result.execution_mode == "manual_only"
    assert result.recommended_actions[0].action_type == "customer_origin_check"


def test_strategy_policy_falls_back_to_manual_review():
    policy = StrategyMapperPolicy()
    result = policy.map({"risk_level": "low", "mitigation_tags": []}, target="example.com")
    assert result.recommended_actions[0].action_type == "manual_review"
