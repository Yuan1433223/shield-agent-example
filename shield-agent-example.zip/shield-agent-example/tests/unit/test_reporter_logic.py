"""Unit tests for reporter node pure functions."""

from __future__ import annotations

from kks_runtime.artifacts.investigation import InvestigationArtifact
from kks_runtime.graph.nodes.reporter import (
    _degraded_recommendations,
    _build_degraded_report,
    _derive_risk_level,
    _format_asset_findings,
    _format_findings,
    _has_degraded_findings,
    _parse_recommendations,
    _stabilize_report_contract,
    _strategy_recommendations,
)
from kks_security.schemas.report import InvestigationReport


def test_derive_risk_level_normal():
    report = InvestigationReport(alert_status="normal")
    assert _derive_risk_level(report) == "low"


def test_derive_risk_level_warning():
    report = InvestigationReport(alert_status="warning")
    assert _derive_risk_level(report) == "medium"


def test_derive_risk_level_critical():
    report = InvestigationReport(alert_status="critical")
    assert _derive_risk_level(report) == "high"


def test_derive_risk_level_none_falls_back_to_medium():
    report = InvestigationReport()
    assert _derive_risk_level(report) == "medium"


def test_parse_recommendations_none():
    assert _parse_recommendations(None) == []


def test_parse_recommendations_placeholder():
    assert _parse_recommendations("[requires analysis]") == []


def test_parse_recommendations_bracket_prefix():
    assert _parse_recommendations("[no data]") == []


def test_parse_recommendations_bullet_list():
    text = "- item one\n- item two\n- item three"
    result = _parse_recommendations(text)
    assert result == ["item one", "item two", "item three"]


def test_parse_recommendations_numbered_list():
    text = "1. First action\n2. Second action\n3. Third action"
    result = _parse_recommendations(text)
    assert result == ["First action", "Second action", "Third action"]


def test_parse_recommendations_single_line():
    text = "Just one recommendation"
    result = _parse_recommendations(text)
    assert result == ["Just one recommendation"]


def test_format_findings_empty():
    assert _format_findings({}) == "No findings collected."


def test_format_findings_sections():
    text = _format_findings({"logs": {"risk_level": "low"}, "security": {"risk_level": "high"}})
    assert "### LOGS FINDINGS" in text
    assert "### SECURITY FINDINGS" in text


def test_format_asset_findings_empty():
    assert _format_asset_findings({}) == "No asset-scoped findings collected."


def test_format_asset_findings_includes_asset_identity_and_worker_results():
    text = _format_asset_findings(
        {
            "GF:node_product:1.1.1.1": {
                "asset": {"ip": "1.1.1.1", "type": "node_product", "source": "GF"},
                "machine": {"summary": "healthy", "risk_level": "low"},
                "security": {"summary": "protected", "risk_level": "medium"},
            }
        }
    )
    assert "GF:node_product:1.1.1.1 | ip=1.1.1.1" in text
    assert "- machine:" in text
    assert "- security:" in text


def test_has_degraded_findings_detects_nested_flag():
    assert _has_degraded_findings(
        {"logs": {"degraded": True}},
        {"asset-1": {"machine": {"degraded": False}}},
    )


def test_build_degraded_report_uses_finding_summaries():
    report = _build_degraded_report(
        target="example.com",
        findings={
            "logs": {"summary": "5xx spike detected", "risk_level": "critical"},
            "security": {"summary": "No CC attack", "risk_level": "low"},
        },
        asset_findings={},
        error_message="model timeout",
    )
    assert report.summary == "Investigation for example.com completed in degraded mode."
    assert "5xx spike detected" in (report.root_cause or "")
    assert report.alert_status == "critical"


def test_strategy_recommendations_extract_titles():
    recs = _strategy_recommendations(
        {
            "recommended_actions": [
                {"title": "Apply URL rate limiting"},
                {"title": "Block top offending IPs on WAF"},
            ]
        }
    )
    assert recs == ["Apply URL rate limiting", "Block top offending IPs on WAF"]


def test_degraded_recommendations_prefer_strategy():
    text = _degraded_recommendations(
        {
            "strategy": {
                "recommended_actions": [
                    {"title": "Apply URL rate limiting"},
                    {"title": "Block top offending IPs on WAF"},
                ]
            }
        }
    )
    assert "Apply URL rate limiting" in text


def test_artifact_risk_level_matches_derive():
    report = InvestigationReport(
        alert_status="critical",
        summary="System is under attack.",
        recommendations="Block offending IPs.\nEnable rate limiting.",
    )
    risk = _derive_risk_level(report)
    recs = _parse_recommendations(report.recommendations)

    artifact = InvestigationArtifact(
        session_id="test-session",
        target="1.2.3.4",
        findings={"security": {"has_attack": True}},
        asset_findings={"GF:product:1.2.3.4": {"security": {"risk_level": "high"}}},
        report=report.model_dump(mode="json"),
        risk_level=risk,
        summary=report.summary or "Investigation complete.",
        recommendations=recs,
    )

    assert artifact.risk_level == "high"
    assert artifact.summary == "System is under attack."
    assert "Block offending IPs." in artifact.recommendations


def test_artifact_summary_fallback():
    report = InvestigationReport(summary=None)
    summary = report.summary or "Investigation complete."
    assert summary == "Investigation complete."


def test_artifact_serialises_to_json():
    report = InvestigationReport(alert_status="normal", summary="All clear.")
    artifact = InvestigationArtifact(
        session_id="s1",
        target="example.com",
        report=report.model_dump(mode="json"),
        risk_level=_derive_risk_level(report),
        summary=report.summary or "Investigation complete.",
        recommendations=_parse_recommendations(report.recommendations),
        degraded=True,
    )
    d = artifact.model_dump(mode="json")
    assert d["artifact_type"] == "investigation"
    assert d["risk_level"] == "low"
    assert d["report"]["summary"] == "All clear."
    assert d["degraded"] is True
    assert isinstance(d["created_at"], str)


def test_stabilize_report_contract_backfills_investigation_and_strategy_fields():
    report = InvestigationReport(
        summary="origin service is failing",
        recommendations="1. Contact the origin owner",
    )

    stabilized = _stabilize_report_contract(
        report,
        findings={
            "investigation": {
                "abnormal_object": "/login",
                "status_origin": "origin",
                "temporal_relation": "error_before_traffic",
                "classification": "non_attack",
                "evidence_tags": ["origin_generated_status", "error_before_traffic"],
                "rationale": "typed evidence indicates origin-generated failures",
            },
            "strategy": {
                "recommended_actions": [
                    {"title": "Contact the origin owner"},
                    {"title": "Inspect upstream retries"},
                ],
                "rationale": "origin checks should be prioritised before edge mitigation",
            },
        },
        degraded=False,
    )

    assert stabilized.abnormal_object == "/login"
    assert stabilized.status_origin == "origin"
    assert stabilized.temporal_relation == "error_before_traffic"
    assert stabilized.classification == "non_attack"
    assert stabilized.evidence_tags == ["origin_generated_status", "error_before_traffic"]
    assert stabilized.recommended_action_titles == [
        "Contact the origin owner",
        "Inspect upstream retries",
    ]
    assert "origin checks should be prioritised" in (stabilized.mitigation_rationale or "")


def test_stabilize_report_contract_marks_degraded_report_text_explicitly():
    report = InvestigationReport(root_cause="origin generated 5xx before traffic growth")

    stabilized = _stabilize_report_contract(
        report,
        findings={},
        degraded=True,
    )

    assert "degraded evidence paths" in (stabilized.root_cause or "")
    assert "degraded evidence paths" in (stabilized.mitigation_rationale or "")
