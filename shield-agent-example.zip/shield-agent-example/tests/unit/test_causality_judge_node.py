from __future__ import annotations

import pytest

from kks_runtime.graph.nodes.causality_judge import causality_judge_node


@pytest.mark.asyncio
async def test_causality_judge_writes_investigation_finding():
    result = await causality_judge_node(
        {
            "target": "example.com",
            "findings": {
                "logs": {
                    "status_origin": "origin",
                    "error_before_traffic": True,
                    "retry_pattern_suspected": True,
                    "upstream_status_present": True,
                    "upstream_response_length_positive": True,
                },
                "security": {"risk_level": "low"},
            },
        }
    )
    investigation = result["findings"]["investigation"]
    assert investigation["classification"] == "non_attack"
    assert investigation["likely_cause"] == "origin_fault_with_client_retry"
    assert investigation["status_origin"] == "origin"
    assert investigation["abnormal_object"] == "example.com"
