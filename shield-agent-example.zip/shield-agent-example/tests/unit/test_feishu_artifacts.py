from kks_surfaces.feishu.artifacts import build_alert_analysis_text, report_from_artifact


# ---------------------------------------------------------------------------
# _backfill_report_metrics — performance_metrics from findings["machine"]
# ---------------------------------------------------------------------------


def test_backfill_populates_performance_metrics_from_machine_findings():
    artifact = {
        "report": {"summary": "test", "alert_status": "warning"},
        "findings": {
            "machine": {"cpu_pct": 0.873, "memory_pct": 0.641, "tcp_established": 1240}
        },
    }
    report = report_from_artifact(artifact)
    assert report.performance_metrics is not None
    assert report.performance_metrics.cpu_usage == "87.3%"
    assert report.performance_metrics.memory_usage == "64.1%"
    assert report.performance_metrics.tcp_connections == "1240"


def test_backfill_skips_performance_when_already_set():
    """If reporter already set performance_metrics, backfill must not overwrite it."""
    artifact = {
        "report": {
            "summary": "test",
            "performance_metrics": {"cpu_usage": "50%", "memory_usage": "30%"},
        },
        "findings": {
            "machine": {"cpu_pct": 0.99, "memory_pct": 0.99}
        },
    }
    report = report_from_artifact(artifact)
    assert report.performance_metrics.cpu_usage == "50%"


def test_backfill_handles_missing_machine_findings_gracefully():
    artifact = {"report": {"summary": "test"}}
    report = report_from_artifact(artifact)
    assert report.performance_metrics is None


def test_backfill_formats_none_cpu_as_unknown():
    artifact = {
        "report": {"summary": "test"},
        "findings": {"machine": {"cpu_pct": None, "memory_pct": None, "tcp_established": None}},
    }
    report = report_from_artifact(artifact)
    assert report.performance_metrics.cpu_usage == "unknown"
    assert report.performance_metrics.tcp_connections == "unknown"


# ---------------------------------------------------------------------------
# _backfill_report_metrics — security_metrics from findings["security"]
# ---------------------------------------------------------------------------


def test_backfill_populates_security_metrics_from_security_findings():
    artifact = {
        "report": {"summary": "test"},
        "findings": {
            "security": {"cc_is_under_attack": True, "ddos_exceeds_threshold": False}
        },
    }
    report = report_from_artifact(artifact)
    assert report.security_metrics is not None
    assert report.security_metrics.has_cc_attack is True
    assert report.security_metrics.has_ddos_attack is False


def test_backfill_skips_security_when_already_set():
    artifact = {
        "report": {
            "summary": "test",
            "security_metrics": {"has_cc_attack": False, "has_ddos_attack": False},
        },
        "findings": {
            "security": {"cc_is_under_attack": True, "ddos_exceeds_threshold": True}
        },
    }
    report = report_from_artifact(artifact)
    assert report.security_metrics.has_cc_attack is False


def test_backfill_handles_missing_security_findings_gracefully():
    artifact = {"report": {"summary": "test"}}
    report = report_from_artifact(artifact)
    assert report.security_metrics is None


def test_backfill_both_dimensions_populated_from_findings():
    artifact = {
        "report": {"summary": "test"},
        "findings": {
            "machine": {"cpu_pct": 0.5, "memory_pct": 0.6},
            "security": {"cc_is_under_attack": False, "ddos_exceeds_threshold": True},
        },
    }
    report = report_from_artifact(artifact)
    assert report.performance_metrics.cpu_usage == "50.0%"
    assert report.security_metrics.has_ddos_attack is True


def test_report_from_artifact_prefers_full_report_payload():
    artifact = {
        "summary": "fallback summary",
        "risk_level": "high",
        "report": {
            "summary": "full report summary",
            "alert_status": "critical",
            "recommendations": "1. isolate\n2. verify",
        },
    }

    report = report_from_artifact(artifact)

    assert report.summary == "full report summary"
    assert report.alert_status == "critical"


def test_build_alert_analysis_text_contains_investigation_and_strategy_sections():
    artifact = {
        "summary": "fallback summary",
        "degraded": True,
        "report": {
            "summary": "origin service is failing",
            "root_cause": "upstream 502 started before traffic growth",
            "performance_conclusion": "node pressure is limited",
            "network_conclusion": "network path is stable",
            "security_conclusion": "no active volumetric attack",
            "request_conclusion": "5xx requests concentrate on one origin path",
            "recommendations": "ask app owner to inspect upstream",
            "alert_status": "critical",
        },
        "findings": {
            "investigation": {
                "abnormal_object": "/login",
                "status_origin": "origin",
                "temporal_relation": "error_before_traffic",
                "classification": "non_attack",
                "likely_cause": "origin_fault_with_client_retry",
                "evidence_tags": ["origin_generated_status", "error_before_traffic"],
                "mitigation_tags": ["customer_origin_check"],
                "rationale": "typed log evidence points to origin-generated failures",
            },
            "strategy": {
                "recommended_actions": [
                    {"title": "Contact the origin owner", "rationale": "origin is failing"},
                    {"title": "Review retry amplification", "rationale": "clients are retrying"},
                ]
            },
        },
    }

    text = build_alert_analysis_text(artifact)

    assert "【核心结论】" in text
    assert "【调查判定】" in text
    assert "异常对象：/login" in text
    assert "【处置建议】" in text
    assert "Contact the origin owner" in text
    assert "【运行状态】" in text
