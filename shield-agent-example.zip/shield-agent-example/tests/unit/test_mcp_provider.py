"""
Unit tests for kks_runtime.tools.mcp_provider.

Covers:
- mcp_tool_context connects to the MCP server with correct config (URL, transport, auth)
- mcp_tool_context filters tools by the provided name frozenset
- mcp_tool_context yields empty list when no tools match the frozenset
- Per-node frozenset constants are non-empty and contain only strings
- machine_check and security_guard toolsets are disjoint
"""

from __future__ import annotations

import sys
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from langchain_core.tools import BaseTool

# ---------------------------------------------------------------------------
# Inject fake langchain_mcp_adapters before importing mcp_provider so the
# lazy import inside mcp_tool_context resolves without the real package.
# ---------------------------------------------------------------------------

_fake_client_module = MagicMock()
sys.modules.setdefault("langchain_mcp_adapters", MagicMock())
sys.modules.setdefault("langchain_mcp_adapters.client", _fake_client_module)

from kks_runtime.tools.mcp_provider import mcp_tool_context  # noqa: E402


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_mock_tool(name: str) -> BaseTool:
    t = MagicMock(spec=BaseTool)
    t.name = name
    return t


def _make_settings(url: str = "http://mcp:9000/sse", timeout: int = 30, token: str = "tok") -> MagicMock:
    s = MagicMock()
    s.mcp_server_url = url
    s.mcp_server_timeout = timeout
    s.mcp_auth_token = token
    return s


def _patch_settings(**kwargs):
    return patch(
        "kks_runtime.config.settings.get_settings",
        return_value=_make_settings(**kwargs),
    )


def _make_mcp_client_cls(tools_to_return: list[BaseTool]):
    mock_client = MagicMock()
    mock_client.get_tools = AsyncMock(return_value=tools_to_return)
    mock_cls = MagicMock(return_value=mock_client)
    return mock_cls


# ---------------------------------------------------------------------------
# Connection config
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_connects_with_correct_url_and_transport():
    """MultiServerMCPClient receives the configured URL and SSE transport."""
    url = "http://mcp-server:19000/sse"
    mock_cls = _make_mcp_client_cls([])
    _fake_client_module.MultiServerMCPClient = mock_cls

    with _patch_settings(url=url, token="secret"):
        async with mcp_tool_context(frozenset()):
            pass

    mock_cls.assert_called_once()
    cfg = mock_cls.call_args.args[0]
    assert "kks" in cfg
    assert cfg["kks"]["url"] == url
    assert cfg["kks"]["transport"] == "sse"


@pytest.mark.asyncio
async def test_sends_bearer_auth_header():
    """Authorization header carries the configured mcp_auth_token."""
    token = "super-secret-jwt"
    mock_cls = _make_mcp_client_cls([])
    _fake_client_module.MultiServerMCPClient = mock_cls

    with _patch_settings(token=token):
        async with mcp_tool_context(frozenset()):
            pass

    cfg = mock_cls.call_args.args[0]
    assert cfg["kks"]["headers"]["Authorization"] == f"Bearer {token}"


@pytest.mark.asyncio
async def test_passes_timeout_to_client():
    """mcp_server_timeout is forwarded inside the SSEConnection config dict."""
    mock_cls = _make_mcp_client_cls([])
    _fake_client_module.MultiServerMCPClient = mock_cls

    with _patch_settings(timeout=45):
        async with mcp_tool_context(frozenset()):
            pass

    cfg = mock_cls.call_args.args[0]
    assert cfg["kks"]["timeout"] == 45


# ---------------------------------------------------------------------------
# Tool filtering
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_filters_to_matching_names():
    """Only tools whose names appear in tool_names are yielded."""
    wanted = frozenset({"tool_a", "tool_c"})
    all_tools = [_make_mock_tool(n) for n in ("tool_a", "tool_b", "tool_c", "tool_d")]
    _fake_client_module.MultiServerMCPClient = _make_mcp_client_cls(all_tools)

    with _patch_settings():
        async with mcp_tool_context(wanted) as tools:
            returned = {t.name for t in tools}

    assert returned == wanted


@pytest.mark.asyncio
async def test_yields_empty_list_when_no_match():
    """Empty list is yielded when the server has no tools in the requested frozenset."""
    all_tools = [_make_mock_tool("unrelated_tool")]
    _fake_client_module.MultiServerMCPClient = _make_mcp_client_cls(all_tools)

    with _patch_settings():
        async with mcp_tool_context(frozenset({"wanted_tool"})) as tools:
            assert tools == []


@pytest.mark.asyncio
async def test_empty_frozenset_yields_empty_list():
    """Empty frozenset → no tools yielded, but server is still contacted."""
    mock_cls = _make_mcp_client_cls([_make_mock_tool("some_tool")])
    _fake_client_module.MultiServerMCPClient = mock_cls

    with _patch_settings():
        async with mcp_tool_context(frozenset()) as tools:
            assert tools == []

    mock_cls.assert_called_once()


# ---------------------------------------------------------------------------
# Per-node frozenset constants
# ---------------------------------------------------------------------------


def test_log_detective_tools_is_nonempty_frozenset():
    from kks_runtime.graph.nodes.log_detective import _LOG_DETECTIVE_TOOLS
    assert isinstance(_LOG_DETECTIVE_TOOLS, frozenset)
    assert len(_LOG_DETECTIVE_TOOLS) > 0
    assert all(isinstance(n, str) for n in _LOG_DETECTIVE_TOOLS)


def test_machine_check_tools_is_nonempty_frozenset():
    from kks_runtime.graph.nodes.machine_check import _MACHINE_CHECK_TOOLS
    assert isinstance(_MACHINE_CHECK_TOOLS, frozenset)
    assert len(_MACHINE_CHECK_TOOLS) > 0
    assert all(isinstance(n, str) for n in _MACHINE_CHECK_TOOLS)


def test_security_guard_tools_is_nonempty_frozenset():
    from kks_runtime.graph.nodes.security_guard import _SECURITY_GUARD_TOOLS
    assert isinstance(_SECURITY_GUARD_TOOLS, frozenset)
    assert len(_SECURITY_GUARD_TOOLS) > 0
    assert all(isinstance(n, str) for n in _SECURITY_GUARD_TOOLS)


def test_log_detective_includes_core_es_tools():
    from kks_runtime.graph.nodes.log_detective import _LOG_DETECTIVE_TOOLS
    for name in ("query_es_raw_logs", "query_es_qps_trend", "query_es_top_n"):
        assert name in _LOG_DETECTIVE_TOOLS, f"{name} missing from _LOG_DETECTIVE_TOOLS"


def test_log_detective_includes_rag_and_knowledge_tools():
    from kks_runtime.graph.nodes.log_detective import _LOG_DETECTIVE_TOOLS
    assert "search_knowledge" in _LOG_DETECTIVE_TOOLS
    assert "get_gf_log_table_structure" in _LOG_DETECTIVE_TOOLS


def test_log_detective_includes_new_diagnostic_tools():
    from kks_runtime.graph.nodes.log_detective import _LOG_DETECTIVE_TOOLS
    for name in (
        "query_status_origin_breakdown",
        "query_error_traffic_timeline",
        "query_targeted_path_patterns",
        "query_header_value_distribution",
        "query_ip_url_binding",
        "query_es_trend_comparison",
    ):
        assert name in _LOG_DETECTIVE_TOOLS, f"{name} missing from _LOG_DETECTIVE_TOOLS"


def test_machine_check_tools_are_disjoint_from_security_guard():
    from kks_runtime.graph.nodes.machine_check import _MACHINE_CHECK_TOOLS
    from kks_runtime.graph.nodes.security_guard import _SECURITY_GUARD_TOOLS
    overlap = _MACHINE_CHECK_TOOLS & _SECURITY_GUARD_TOOLS
    assert not overlap, f"Unexpected overlap between machine/security toolsets: {overlap}"
