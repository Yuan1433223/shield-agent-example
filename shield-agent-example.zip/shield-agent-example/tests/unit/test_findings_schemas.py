import json

from kks_security.schemas.findings import (
    IPURLBindingEvidence,
    InvestigationFindings,
    LogFindings,
    MachineTrendEvidence,
    MachineFindings,
    SecurityFindings,
    StrategyFindings,
    ValueDistributionEvidence,
)


def test_log_findings_defaults():
    f = LogFindings(summary="test")
    assert f.risk_level == "medium"
    assert f.error_rate == {}
    assert f.top_errors == []
    assert f.trend_comparison is None
    assert f.status_origin == "unknown"
    assert f.origin_status_codes == []
    assert f.edge_status_codes == []
    assert f.targeted_paths == []
    assert f.dominant_user_agent is None
    assert f.dominant_header_value is None
    assert f.top_ip_url_binding is None
    assert f.header_anomalies == []
    assert f.collection_status == "complete"
    assert f.degraded is False


def test_log_findings_full():
    f = LogFindings(
        summary="QPS spike detected",
        qps_info="avg 500 rps, peak 2000 rps",
        error_rate={"4xx": "12%", "5xx": "3%"},
        top_errors=["502: /api/v1 x1200", "403: /admin x800"],
        risk_level="high",
    )
    d = f.model_dump()
    assert d["risk_level"] == "high"
    assert d["error_rate"]["4xx"] == "12%"


def test_log_findings_wll_fields():
    f = LogFindings(
        summary="Origin 502 spike",
        status_origin="origin",
        origin_status_codes=[502],
        upstream_status_present=True,
        upstream_response_length_positive=True,
        error_started_at="2026-05-08 10:00:00",
        traffic_started_at="2026-05-08 10:02:00",
        error_before_traffic=True,
        retry_pattern_suspected=True,
        targeted_paths=["/api/trade/create"],
        targeted_directories=["/api/trade"],
        dominant_user_agent=ValueDistributionEvidence(
            field_name="http_user_agent",
            dominant_value="khttp/3.12.6",
            share=0.65,
            count=65,
            total_docs=100,
        ),
        dominant_header_value=ValueDistributionEvidence(
            field_name="http_x_forwarded_for",
            dominant_value="127.0.0.1",
            share=0.61,
            count=61,
            total_docs=100,
        ),
        top_ip_url_binding=IPURLBindingEvidence(
            client_ip="1.2.3.4",
            url="/api/trade/create",
            binding_count=55,
            client_ip_total=60,
            binding_share_within_ip=0.9167,
            binding_share_global=0.55,
        ),
        ua_anomalies=["khttp/3.12.6 concentration"],
        header_anomalies=["x-forwarded-for=127.0.0.1"],
        ip_growth_signals=["single-netblock concentration"],
    )
    d = f.model_dump(mode="json")
    assert d["status_origin"] == "origin"
    assert d["origin_status_codes"] == [502]
    assert d["error_before_traffic"] is True
    assert d["targeted_paths"] == ["/api/trade/create"]
    assert d["dominant_user_agent"]["share"] == 0.65
    assert d["top_ip_url_binding"]["binding_share_within_ip"] == 0.9167


def test_security_findings_defaults():
    f = SecurityFindings(summary="Protection active")
    assert f.cc_status == "unknown"
    assert f.ddos_status == "unknown"
    assert f.risk_level == "medium"
    assert f.operational_issue == "none"


def test_machine_findings_health_status():
    f = MachineFindings(summary="All green", health_status="healthy", risk_level="low")
    assert f.health_status == "healthy"
    assert f.risk_level == "low"
    assert f.connection_trend is None
    assert f.request_hole is None


def test_machine_findings_wll_fields():
    f = MachineFindings(
        summary="Connection pressure observed",
        health_status="degraded",
        connection_trend=MachineTrendEvidence(
            metric_name="connection_trend",
            query_used='node_netstat_Tcp_CurrEstab{instance="1.2.3.4:9100"}',
            unit="connections",
            peak_value=18000,
            started_at="2026-05-08 10:00:00",
            sample_count=10,
            spike_detected=True,
        ),
        response_time_trend=MachineTrendEvidence(
            metric_name="response_time_trend",
            query_used='avg(upstream_response_time{instance="1.2.3.4:9100"})',
            unit="seconds",
            peak_value=0.9,
            started_at="2026-05-08 10:01:00",
            sample_count=10,
            spike_detected=True,
        ),
        back_to_origin_trend=MachineTrendEvidence(
            metric_name="back_to_origin_trend",
            query_used='sum(rate(upstream_requests_total{instance="1.2.3.4:9100"}[60s]))',
            unit="rps",
            peak_value=1200,
            started_at="2026-05-08 10:01:00",
            sample_count=10,
            spike_detected=False,
        ),
        connection_spike=True,
        request_hole=True,
        response_time_spike=True,
        back_to_origin_spike=False,
    )
    d = f.model_dump(mode="json")
    assert d["connection_trend"]["peak_value"] == 18000
    assert d["request_hole"] is True


def test_investigation_findings_defaults():
    f = InvestigationFindings()
    assert f.status_origin == "unknown"
    assert f.temporal_relation == "unknown"
    assert f.classification == "unknown"
    assert f.evidence_tags == []
    assert f.mitigation_tags == []


def test_strategy_findings_defaults():
    f = StrategyFindings()
    assert f.execution_mode == "manual_only"
    assert f.recommended_actions == []


def test_degraded_findings_dump_json_serialisable():
    f = InvestigationFindings(
        summary="fallback classification unavailable",
        degraded=True,
        collection_status="failed",
        error_code="causality_judge.TimeoutError",
        error_message="request timed out",
    )
    raw = f.model_dump(mode="json")
    json.dumps(raw)
    assert raw["degraded"] is True
    assert raw["collection_status"] == "failed"
