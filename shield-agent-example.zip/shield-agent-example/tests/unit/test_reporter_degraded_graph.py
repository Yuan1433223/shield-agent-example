from __future__ import annotations

import dataclasses
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from langchain_core.messages import HumanMessage
from langgraph.checkpoint.memory import MemorySaver

from kks_runtime.events.protocol import ErrorEvent, FinalEvent
from kks_runtime.graph.investigation import build_investigation_graph
from kks_security.policies.evidence import default_policy

_SUPERVISOR_PATH = "kks_runtime.graph.nodes.supervisor.build_model"
_REPORTER_PATH = "kks_runtime.graph.nodes.reporter.build_model"
_DEFAULT_POLICY_PATH = "kks_runtime.graph.nodes.supervisor.default_policy"


def _mock_supervisor_llm() -> MagicMock:
    task_decision = MagicMock()
    task_decision.agent_task = "Investigate the target as instructed."
    mock_structured = AsyncMock(return_value=task_decision)
    mock_llm = MagicMock()
    mock_llm.with_structured_output.return_value = MagicMock(ainvoke=mock_structured)
    return mock_llm


def _failing_reporter_llm() -> MagicMock:
    mock_structured = AsyncMock(side_effect=RuntimeError("report model timeout"))
    mock_llm = MagicMock()
    mock_llm.with_structured_output.return_value = MagicMock(ainvoke=mock_structured)
    return mock_llm


def _no_hitl_policy():
    return dataclasses.replace(default_policy(), hitl_required_for_critical=False)


@pytest.mark.asyncio
async def test_reporter_failure_falls_back_to_degraded_artifact():
    graph = build_investigation_graph(checkpointer=MemorySaver())
    thread_id = "reporter-degraded"
    findings = {
        "logs": {"summary": "5xx spike detected", "risk_level": "critical"},
        "security": {"summary": "No CC attack", "risk_level": "low"},
    }

    with (
        patch(_SUPERVISOR_PATH, return_value=_mock_supervisor_llm()),
        patch(_REPORTER_PATH, return_value=_failing_reporter_llm()),
        patch(_DEFAULT_POLICY_PATH, return_value=_no_hitl_policy()),
    ):
        result = await graph.ainvoke(
            {
                "messages": [HumanMessage(content="investigate example.com")],
                "target": "example.com",
                "session_id": thread_id,
                "findings": findings,
            },
            config={"configurable": {"thread_id": thread_id}},
        )

    assert result["status"] == "completed"
    artifact = result["artifacts"][0]
    assert artifact["artifact_type"] == "investigation"
    assert artifact["degraded"] is True
    assert "degraded mode" in artifact["summary"]
    assert artifact["report"]["alert_status"] == "critical"


@pytest.mark.asyncio
async def test_reporter_failure_emits_error_event_and_final_event():
    graph = build_investigation_graph(checkpointer=MemorySaver())
    thread_id = "reporter-degraded-stream"
    events: list = []

    with (
        patch(_SUPERVISOR_PATH, return_value=_mock_supervisor_llm()),
        patch(_REPORTER_PATH, return_value=_failing_reporter_llm()),
        patch(_DEFAULT_POLICY_PATH, return_value=_no_hitl_policy()),
    ):
        async for chunk in graph.astream(
            {
                "messages": [HumanMessage(content="investigate example.com")],
                "target": "example.com",
                "session_id": thread_id,
                "findings": {"logs": {"summary": "5xx spike", "risk_level": "high"}},
            },
            config={"configurable": {"thread_id": thread_id}},
            stream_mode="custom",
        ):
            events.append(chunk)

    assert any(isinstance(evt, ErrorEvent) and evt.node == "reporter" for evt in events)
    assert any(isinstance(evt, FinalEvent) for evt in events)
