from langchain_core.messages import AIMessage, HumanMessage, ToolMessage

from kks_runtime.graph.nodes._extraction_context import build_extraction_context


def test_build_extraction_context_includes_tool_outputs_and_final_analysis():
    context = build_extraction_context(
        [
            HumanMessage(content="analyse example.com"),
            AIMessage(content="", tool_calls=[{"name": "query_header_value_distribution", "id": "call-1", "args": {}}]),
            ToolMessage(
                content='{"top_values":[{"value":"curl/8.0","count":65,"share":0.65}]}',
                tool_call_id="call-1",
                name="query_header_value_distribution",
            ),
            AIMessage(content="发现 UA curl/8.0 占比 65%，请求集中。"),
        ]
    )

    assert "[tool:query_header_value_distribution]" in context
    assert "curl/8.0" in context
    assert "[analysis]" in context
    assert "请求集中" in context
