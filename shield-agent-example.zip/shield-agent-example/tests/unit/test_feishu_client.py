import httpx
import respx

from kks_surfaces.feishu.client import FeishuClient, FeishuTableConfig


@respx.mock
async def test_save_alert_analysis_resolves_wiki_token_and_inserts_record():
    auth_route = respx.post("https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal").mock(
        return_value=httpx.Response(
            200,
            json={"code": 0, "tenant_access_token": "tenant-token", "expire": 7200},
        )
    )
    node_route = respx.get("https://open.feishu.cn/open-apis/wiki/v2/spaces/get_node").mock(
        return_value=httpx.Response(
            200,
            json={"code": 0, "data": {"node": {"obj_token": "basc-resolved"}}},
        )
    )
    insert_route = respx.post(
        "https://open.feishu.cn/open-apis/bitable/v1/apps/basc-resolved/tables/tbl-alert/records"
    ).mock(
        return_value=httpx.Response(
            200,
            json={"code": 0, "data": {"record": {"record_id": "rec-alert-1"}}},
        )
    )

    client = FeishuClient(
        app_id="cli_xxx",
        app_secret="sec_xxx",
        alert_table=FeishuTableConfig(app_token="wiki-node-token", table_id="tbl-alert"),
    )

    record_id = await client.save_alert_analysis(
        alert_time="2026-05-08T10:00:00+08:00",
        alert_name="cpu high",
        alert_entity="1.2.3.4",
        analysis_question="why is cpu high",
        ai_analysis_result="root cause text",
    )

    assert record_id == "rec-alert-1"
    assert auth_route.called
    assert node_route.called
    assert insert_route.called
    payload = insert_route.calls[0].request.content.decode("utf-8")
    assert "告警实体" in payload
    assert "1.2.3.4" in payload
