"""Unit tests for Feishu delivery adapter."""

import httpx
import pytest
import respx

from kks_security.schemas.report import (
    InvestigationReport,
    PerformanceMetrics,
    RequestMetrics,
    SecurityMetrics,
)
from kks_surfaces.feishu.delivery import (
    _safe_str,
    build_firing_alert_payload,
    report_to_feishu_payload,
    report_to_feishu_template_payload,
    send_payload_to_feishu,
)


def _make_report(**kwargs) -> InvestigationReport:
    defaults = {
        "alert_status": "warning",
        "summary": "System is experiencing elevated error rates.",
        "recommendations": "Check the application logs and restart if necessary.",
        "root_cause": "Traffic spike caused 502 errors on the upstream.",
        "performance_conclusion": "CPU and memory are normal.",
        "security_conclusion": "No active attack detected.",
        "network_conclusion": "Connectivity is stable.",
        "request_conclusion": "Error rate is 8%, above normal.",
    }
    defaults.update(kwargs)
    return InvestigationReport(**defaults)


# ---------------------------------------------------------------------------
# report_to_feishu_payload structure
# ---------------------------------------------------------------------------


def test_payload_has_msg_type_interactive():
    payload = report_to_feishu_payload(_make_report(), "example.com")
    assert payload["msg_type"] == "interactive"


def test_payload_has_card_key():
    payload = report_to_feishu_payload(_make_report(), "example.com")
    assert "card" in payload


def test_card_has_header():
    card = report_to_feishu_payload(_make_report(), "example.com")["card"]
    assert "header" in card
    assert "title" in card["header"]


def test_card_title_contains_entity():
    card = report_to_feishu_payload(_make_report(), "1.2.3.4")["card"]
    title_text = card["header"]["title"]["content"]
    assert "1.2.3.4" in title_text


def test_card_title_contains_status():
    card = report_to_feishu_payload(_make_report(alert_status="critical"), "x.com")["card"]
    title_text = card["header"]["title"]["content"]
    assert "CRITICAL" in title_text


def test_card_has_elements():
    card = report_to_feishu_payload(_make_report(), "example.com")["card"]
    assert len(card["elements"]) >= 1


def test_card_body_contains_summary():
    card = report_to_feishu_payload(_make_report(), "example.com")["card"]
    body = card["elements"][0]["content"]
    assert "System is experiencing" in body


def test_card_body_contains_recommendations():
    card = report_to_feishu_payload(_make_report(), "example.com")["card"]
    body = card["elements"][0]["content"]
    assert "restart if necessary" in body


def test_card_body_contains_root_cause():
    card = report_to_feishu_payload(_make_report(), "example.com")["card"]
    body = card["elements"][0]["content"]
    assert "Traffic spike" in body


def test_card_body_contains_explicit_investigation_fields():
    card = report_to_feishu_payload(
        _make_report(
            abnormal_object="/login",
            status_origin="origin",
            temporal_relation="error_before_traffic",
            classification="non_attack",
            evidence_tags=["origin_generated_status", "error_before_traffic"],
            mitigation_rationale="Origin verification should happen before edge blocking.",
        ),
        "example.com",
    )["card"]
    body = card["elements"][0]["content"]
    assert "**Investigation**" in body
    assert "Object: /login" in body
    assert "Status Origin: origin" in body
    assert "Mitigation Rationale" in body


# ---------------------------------------------------------------------------
# Card color by alert_status
# ---------------------------------------------------------------------------


def test_normal_status_gives_green_card():
    card = report_to_feishu_payload(_make_report(alert_status="normal"), "x")["card"]
    assert card["header"]["template"] == "green"


def test_warning_status_gives_yellow_card():
    card = report_to_feishu_payload(_make_report(alert_status="warning"), "x")["card"]
    assert card["header"]["template"] == "yellow"


def test_critical_status_gives_red_card():
    card = report_to_feishu_payload(_make_report(alert_status="critical"), "x")["card"]
    assert card["header"]["template"] == "red"


def test_unknown_status_gives_blue_card():
    """An unrecognised status string falls back to blue."""
    from kks_surfaces.feishu.delivery import _card_color

    assert _card_color("something_else") == "blue"


# ---------------------------------------------------------------------------
# Minimal report (sparse findings)
# ---------------------------------------------------------------------------


def test_minimal_report_still_produces_valid_payload():
    report = InvestigationReport()
    payload = report_to_feishu_payload(report, "unknown")
    assert payload["msg_type"] == "interactive"
    assert "card" in payload


# ---------------------------------------------------------------------------
# _safe_str helper
# ---------------------------------------------------------------------------


def test_safe_str_returns_empty_for_none():
    assert _safe_str(None) == ""


def test_safe_str_returns_empty_for_placeholder():
    assert _safe_str("[requires analysis]") == ""


def test_safe_str_returns_empty_for_unknown():
    assert _safe_str("unknown") == ""


def test_safe_str_passes_through_real_value():
    assert _safe_str("87.3%") == "87.3%"


# ---------------------------------------------------------------------------
# report_to_feishu_template_payload structure
# ---------------------------------------------------------------------------

_ALERT_META = {
    "alertnames": "HighErrorRate / DDoS",
    "starts_at": "2026-05-11T03:00:00Z",
    "firing_count": 2,
    "question": "What happened to api.example.com?",
    "entity_type": "domain",
}


def _make_template_report(**kwargs) -> InvestigationReport:
    defaults = {
        "alert_status": "critical",
        "summary": "大量 5xx，源站故障",
        "performance_conclusion": "CPU 正常，内存偏高",
        "security_conclusion": "无活跃 DDoS",
        "network_conclusion": "连通性正常",
        "request_conclusion": "5xx 占比 32%",
        "performance_metrics": PerformanceMetrics(cpu_usage="45%", memory_usage="82%"),
        "security_metrics": SecurityMetrics(has_cc_attack=True, has_ddos_attack=False),
        "request_metrics": RequestMetrics(status_code_distribution="200:68%, 5xx:32%"),
    }
    defaults.update(kwargs)
    return InvestigationReport(**defaults)


def test_template_payload_msg_type_is_interactive():
    payload = report_to_feishu_template_payload(
        _make_template_report(), "api.example.com",
        alert_meta=_ALERT_META, template_id="tpl_001", template_version="1.0.0",
    )
    assert payload["msg_type"] == "interactive"


def test_template_payload_card_type_is_template():
    payload = report_to_feishu_template_payload(
        _make_template_report(), "api.example.com",
        alert_meta=_ALERT_META, template_id="tpl_001", template_version="1.0.0",
    )
    assert payload["card"]["type"] == "template"


def test_template_payload_contains_template_id_and_version():
    payload = report_to_feishu_template_payload(
        _make_template_report(), "api.example.com",
        alert_meta=_ALERT_META, template_id="tpl_XYZ", template_version="2.1.0",
    )
    data = payload["card"]["data"]
    assert data["template_id"] == "tpl_XYZ"
    assert data["template_version_name"] == "2.1.0"


def test_template_variable_alert_fields():
    tv = report_to_feishu_template_payload(
        _make_template_report(), "api.example.com",
        alert_meta=_ALERT_META, template_id="tpl_001", template_version="1.0.0",
    )["card"]["data"]["template_variable"]
    assert tv["alert_title"] == "HighErrorRate / DDoS"
    assert tv["alert_entity"] == "api.example.com"
    assert tv["alert_time"] == "2026-05-11T03:00:00Z"
    assert tv["alert_count"] == 2
    assert tv["entity_type"] == "domain"
    assert tv["question"] == "What happened to api.example.com?"


def test_template_variable_ai_name_is_claude():
    tv = report_to_feishu_template_payload(
        _make_template_report(), "x.com",
        alert_meta=_ALERT_META, template_id="t", template_version="1",
    )["card"]["data"]["template_variable"]
    assert tv["ai_name"] == "claude"


def test_template_variable_cpu_and_memory_from_metrics():
    tv = report_to_feishu_template_payload(
        _make_template_report(), "x.com",
        alert_meta=_ALERT_META, template_id="t", template_version="1",
    )["card"]["data"]["template_variable"]
    assert tv["cpu_usage"] == "45%"
    assert tv["memory_usage"] == "82%"


def test_template_variable_has_cc_attack_true():
    tv = report_to_feishu_template_payload(
        _make_template_report(), "x.com",
        alert_meta=_ALERT_META, template_id="t", template_version="1",
    )["card"]["data"]["template_variable"]
    assert tv["has_cc_attack"] is True
    assert tv["has_ddos_attack"] is False


def test_template_variable_status_code_from_request_metrics():
    tv = report_to_feishu_template_payload(
        _make_template_report(), "x.com",
        alert_meta=_ALERT_META, template_id="t", template_version="1",
    )["card"]["data"]["template_variable"]
    assert "5xx" in tv["status_code"]


def test_template_variable_processed_url_defaults_empty():
    tv = report_to_feishu_template_payload(
        _make_template_report(), "x.com",
        alert_meta=_ALERT_META, template_id="t", template_version="1",
    )["card"]["data"]["template_variable"]
    assert tv["processed_url"] == ""


def test_template_variable_processed_url_passed_through():
    tv = report_to_feishu_template_payload(
        _make_template_report(), "x.com",
        alert_meta=_ALERT_META, template_id="t", template_version="1",
        processed_url="https://internal.ops/done",
    )["card"]["data"]["template_variable"]
    assert tv["processed_url"] == "https://internal.ops/done"


def test_template_variable_empty_when_metrics_are_none():
    """When performance_metrics and security_metrics are None, fields default to empty/False."""
    report = _make_template_report(performance_metrics=None, security_metrics=None)
    tv = report_to_feishu_template_payload(
        report, "x.com",
        alert_meta=_ALERT_META, template_id="t", template_version="1",
    )["card"]["data"]["template_variable"]
    assert tv["cpu_usage"] == ""
    assert tv["memory_usage"] == ""
    assert tv["has_cc_attack"] is False
    assert tv["has_ddos_attack"] is False


# ---------------------------------------------------------------------------
# build_firing_alert_payload
# ---------------------------------------------------------------------------

from kks_surfaces.webhook.schemas import GrafanaAlert


def _make_alert(alertname: str, starts_at: str = "2026-05-12T03:00:00Z", panel_url: str | None = None) -> GrafanaAlert:
    return GrafanaAlert(
        status="firing",
        labels={"alertname": alertname},
        annotations={},
        startsAt=starts_at,
        endsAt=starts_at,
        generatorURL="http://grafana/gen",
        panelURL=panel_url,
    )


def test_firing_payload_msg_type_interactive():
    payload = build_firing_alert_payload("api.example.com", [_make_alert("HighError")])
    assert payload["msg_type"] == "interactive"


def test_firing_payload_header_template_red():
    card = build_firing_alert_payload("api.example.com", [_make_alert("X")])["card"]
    assert card["header"]["template"] == "red"


def test_firing_payload_title_contains_entity():
    card = build_firing_alert_payload("1.2.3.4", [_make_alert("X")])["card"]
    assert "1.2.3.4" in card["header"]["title"]["content"]


def test_firing_payload_body_contains_alertname():
    card = build_firing_alert_payload("x.com", [_make_alert("HighErrorRate")])["card"]
    body = card["elements"][0]["content"]
    assert "HighErrorRate" in body


def test_firing_payload_body_contains_formatted_timestamp():
    card = build_firing_alert_payload("x.com", [_make_alert("X", starts_at="2026-05-12T03:00:00Z")])["card"]
    body = card["elements"][0]["content"]
    assert "2026-05-12 03:00:00" in body


def test_firing_payload_body_contains_panel_url():
    alert = _make_alert("X", panel_url="https://grafana/d/abc?orgId=1")
    card = build_firing_alert_payload("x.com", [alert])["card"]
    body = card["elements"][0]["content"]
    assert "grafana/d/abc" in body


def test_firing_payload_body_omits_panel_url_when_absent():
    card = build_firing_alert_payload("x.com", [_make_alert("X")])["card"]
    body = card["elements"][0]["content"]
    assert "查看面板" not in body


def test_firing_payload_analysis_started_shows_indicator():
    card = build_firing_alert_payload("x.com", [_make_alert("X")], analysis_started=True)["card"]
    body = card["elements"][0]["content"]
    assert "AI 智能巡检" in body


def test_firing_payload_analysis_not_started_no_indicator():
    card = build_firing_alert_payload("x.com", [_make_alert("X")], analysis_started=False)["card"]
    body = card["elements"][0]["content"]
    assert "AI 智能巡检" not in body


def test_firing_payload_multiple_alerts_all_listed():
    alerts = [_make_alert("AlertA"), _make_alert("AlertB")]
    body = build_firing_alert_payload("x.com", alerts)["card"]["elements"][0]["content"]
    assert "AlertA" in body
    assert "AlertB" in body


# ---------------------------------------------------------------------------
# send_payload_to_feishu
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_send_payload_returns_true_on_success():
    with respx.mock:
        respx.post("https://open.feishu.cn/hook/test").mock(
            return_value=httpx.Response(200, json={"code": 0})
        )
        result = await send_payload_to_feishu(
            "https://open.feishu.cn/hook/test", {"msg_type": "text"}
        )
    assert result is True


@pytest.mark.asyncio
async def test_send_payload_returns_false_on_non_200():
    with respx.mock:
        respx.post("https://open.feishu.cn/hook/test").mock(
            return_value=httpx.Response(500)
        )
        result = await send_payload_to_feishu(
            "https://open.feishu.cn/hook/test", {"msg_type": "text"}
        )
    assert result is False


@pytest.mark.asyncio
async def test_send_payload_returns_false_on_nonzero_code():
    with respx.mock:
        respx.post("https://open.feishu.cn/hook/test").mock(
            return_value=httpx.Response(200, json={"code": 19001, "msg": "invalid token"})
        )
        result = await send_payload_to_feishu(
            "https://open.feishu.cn/hook/test", {"msg_type": "text"}
        )
    assert result is False


@pytest.mark.asyncio
async def test_send_payload_returns_true_when_no_json_body():
    with respx.mock:
        respx.post("https://open.feishu.cn/hook/test").mock(
            return_value=httpx.Response(200, content=b"ok")
        )
        result = await send_payload_to_feishu(
            "https://open.feishu.cn/hook/test", {"msg_type": "text"}
        )
    assert result is True
