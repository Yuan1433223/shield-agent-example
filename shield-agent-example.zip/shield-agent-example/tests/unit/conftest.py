"""Shared fixtures for Phase 6 unit tests."""
import re
from unittest.mock import patch

import pytest

from kks_runtime.config.settings import Settings

_IPV4_RE = re.compile(r"^\d{1,3}(\.\d{1,3}){3}$")


async def _stub_asset_resolution(state: dict) -> dict:
    """No-MCP stub for asset_resolution_node used by all graph-level tests."""
    target = state.get("target", "").strip()
    is_ip = bool(_IPV4_RE.match(target))
    return {
        "target_type": "ip" if is_ip else "domain",
        "resolved_target": target,
        "source_type": "GF",
        "resolution_reason": "stub",
        "node_ips": [target] if is_ip else [],
        "product_ips": [target] if is_ip else [],
        "capability_scope": {
            "log": ["target"],
            "machine": [target] if is_ip else [],
            "security": [target] if is_ip else ["domain_policy"],
        },
        "inspection_scope": [],
    }


@pytest.fixture(autouse=True)
def _patch_asset_resolution():
    """Patch asset_resolution_node for all unit tests so no MCP calls are made."""
    with patch(
        "kks_runtime.graph.investigation.asset_resolution_node",
        _stub_asset_resolution,
    ):
        yield


@pytest.fixture
def test_settings() -> Settings:
    """Minimal Settings with fake URLs — never hits real services."""
    return Settings(
        cc_api_url="http://fake-cc",
        cc_api_key="test-cc-key",
        cc_request_timeout=5,
        ddos_api_url="http://fake-ddos",
        ddos_api_key="test-ddos-key",
        ddos_token="test-ddos-token",
        ddos_request_timeout=5,
        es_url="http://fake-es:9200",
        es_username="",
        es_password="",
        prometheus_url="http://fake-prom:9090",
        prometheus_request_timeout=5,
        prometheus_node_port=9100,
        waf_api_url="http://fake-waf",
        waf_api_token="test-waf-token",
        waf_request_timeout=5,
        gf_yxd_api_url="http://fake-gf-yxd",
        gf_yxd_api_xtoken="test-yxd-token",
        gf_cdn_api_url="http://fake-gf-cdn",
        gf_cdn_api_xtoken="test-cdn-token",
        gf_ddos_api_url="http://fake-gf-ddos",
        gf_ddos_api_xtoken="test-gf-ddos-token",
        gf_request_timeout=5,
        # Attack thresholds (explicit for policy tests)
        cc_attack_pps_threshold=2000,
        cc_attack_delta_threshold=1000,
        ddos_attack_kbps_threshold=1_000_000,
    )
