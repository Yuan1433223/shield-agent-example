from datetime import timedelta

import pytest

from kks_runtime.config.settings import Settings
from kks_runtime.config.time_windows import normalize_analysis_window, previous_window, shift_window


def test_normalize_analysis_window_applies_offset():
    window = normalize_analysis_window(
        "2026-05-07 10:00:00",
        "2026-05-07 10:10:00",
        settings=Settings(alert_end_offset_seconds=30),
    )
    assert window.start_time == "2026-05-07 10:00:00"
    assert window.end_time == "2026-05-07 10:09:30"
    assert window.duration_seconds == 570


def test_previous_window_uses_same_duration():
    window = previous_window("2026-05-07 10:00:00", "2026-05-07 10:15:00")
    assert window.start_time == "2026-05-07 09:45:00"
    assert window.end_time == "2026-05-07 10:00:00"


def test_shift_window_moves_both_edges():
    window = shift_window(
        "2026-05-07 10:00:00",
        "2026-05-07 10:15:00",
        delta=-timedelta(days=1),
    )
    assert window.start_time == "2026-05-06 10:00:00"
    assert window.end_time == "2026-05-06 10:15:00"


def test_normalize_analysis_window_rejects_negative_duration():
    with pytest.raises(ValueError):
        normalize_analysis_window(
            "2026-05-07 10:00:00",
            "2026-05-07 10:00:10",
            end_offset_seconds=20,
        )
