from __future__ import annotations

import pytest

from kks_runtime.graph.nodes.strategy_mapper import strategy_mapper_node


@pytest.mark.asyncio
async def test_strategy_mapper_writes_strategy_finding():
    result = await strategy_mapper_node(
        {
            "target": "example.com",
            "findings": {
                "investigation": {
                    "risk_level": "critical",
                    "likely_cause": "targeted_cc_attack",
                    "abnormal_object": "/api/trade/create",
                    "mitigation_tags": ["url_rate_limit", "ip_block_or_cap"],
                }
            },
        }
    )
    strategy = result["findings"]["strategy"]
    assert strategy["risk_level"] == "critical"
    assert strategy["execution_mode"] == "dry_run_only"
    assert strategy["recommended_actions"][0]["action_type"] == "url_rate_limit"
