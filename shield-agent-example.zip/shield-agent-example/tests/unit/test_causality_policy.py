from kks_security.policies.causality import CausalityPolicy, OriginAttributionPolicy


def test_origin_attribution_policy_prefers_explicit_status_origin():
    policy = OriginAttributionPolicy()
    assert policy.classify({"status_origin": "mixed"}) == "mixed"


def test_origin_attribution_policy_uses_upstream_signals():
    policy = OriginAttributionPolicy()
    result = policy.classify(
        {
            "upstream_status_present": True,
            "upstream_response_length_positive": True,
            "top_errors": ["502 /api"],
        }
    )
    assert result == "origin"


def test_causality_policy_origin_fault_with_client_retry():
    policy = CausalityPolicy()
    result = policy.evaluate(
        logs={
            "status_origin": "origin",
            "error_before_traffic": True,
            "retry_pattern_suspected": True,
            "upstream_status_present": True,
            "upstream_response_length_positive": True,
        }
    )
    assert result.classification == "non_attack"
    assert result.likely_cause == "origin_fault_with_client_retry"
    assert "customer_origin_check" in result.mitigation_tags


def test_causality_policy_targeted_cc_attack():
    policy = CausalityPolicy()
    result = policy.evaluate(
        logs={
            "targeted_paths": ["/api/trade/create"],
            "targeted_directories": ["/api/trade"],
            "single_ip_single_url_burst": True,
            "header_anomalies": ["x-forwarded-for=127.0.0.1"],
            "ua_anomalies": ["curl concentration"],
        },
        security={"cc_is_under_attack": True},
    )
    assert result.classification == "attack"
    assert result.likely_cause == "targeted_cc_attack"
    assert "targeted_path" in result.evidence_tags
    assert "url_rate_limit" in result.mitigation_tags
    assert result.abnormal_object == "/api/trade/create"


def test_causality_policy_uses_typed_distribution_and_binding_evidence():
    policy = CausalityPolicy()
    result = policy.evaluate(
        logs={
            "dominant_user_agent": {
                "field_name": "http_user_agent",
                "dominant_value": "curl/8.0",
                "share": 0.65,
            },
            "dominant_header_value": {
                "field_name": "http_x_forwarded_for",
                "dominant_value": "127.0.0.1",
                "share": 0.58,
            },
            "top_ip_url_binding": {
                "client_ip": "1.2.3.4",
                "url": "/admin/login",
                "binding_share_within_ip": 0.92,
                "binding_share_global": 0.44,
            },
        }
    )
    assert result.classification == "attack"
    assert result.likely_cause == "targeted_cc_attack"
    assert "ua_anomaly" in result.evidence_tags
    assert "header_anomaly" in result.evidence_tags
    assert "single_ip_single_url" in result.evidence_tags
    assert result.abnormal_object == "/admin/login"


def test_causality_policy_node_pressure_attack():
    policy = CausalityPolicy()
    result = policy.evaluate(
        logs={"targeted_paths": ["/admin/login"]},
        machine={
            "connection_spike": True,
            "request_hole": True,
            "response_time_spike": True,
            "risk_level": "high",
        },
    )
    assert result.classification == "attack"
    assert result.likely_cause == "node_pressure_attack"
    assert "connection_spike" in result.evidence_tags
    assert "request_hole" in result.evidence_tags


def test_causality_policy_edge_absorbed_attack():
    policy = CausalityPolicy()
    result = policy.evaluate(
        logs={
            "status_origin": "edge",
            "targeted_directories": ["/wp-admin"],
            "ip_growth_signals": ["many source IPs"],
        },
        security={"risk_level": "high"},
    )
    assert result.classification == "attack"
    assert result.likely_cause == "edge_absorbed_attack"
    assert "observe_edge_rules" in result.mitigation_tags


def test_causality_policy_falls_back_to_origin_generated_fault():
    policy = CausalityPolicy()
    result = policy.evaluate(
        logs={
            "upstream_status_present": True,
            "upstream_response_length_positive": True,
        }
    )
    assert result.classification == "non_attack"
    assert result.likely_cause == "origin_generated_fault"


def test_causality_policy_unknown_when_signals_missing():
    policy = CausalityPolicy()
    result = policy.evaluate(logs={})
    assert result.classification == "unknown"
    assert result.status_origin == "unknown"
