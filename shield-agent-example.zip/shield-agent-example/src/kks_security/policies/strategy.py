"""Deterministic strategy mapping from investigation findings to actions."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from kks_security.schemas.findings import StrategyAction, StrategyFindings


def _add_action(actions: list[StrategyAction], action: StrategyAction) -> None:
    if any(existing.action_type == action.action_type for existing in actions):
        return
    actions.append(action)


def _max_execution_mode(actions: list[StrategyAction]) -> str:
    if any(action.execution_mode == "tool_ready" for action in actions):
        return "tool_ready"
    if any(action.execution_mode == "dry_run_ready" for action in actions):
        return "dry_run_only"
    return "manual_only"


@dataclass(frozen=True)
class StrategyMapperPolicy:
    """Map mitigation tags and likely cause to stable recommended actions."""

    def map(self, investigation: dict[str, Any] | None = None, *, target: str | None = None) -> StrategyFindings:
        investigation = investigation or {}
        tags = set(investigation.get("mitigation_tags") or [])
        likely_cause = investigation.get("likely_cause")
        risk_level = investigation.get("risk_level", "medium")
        abnormal_object = investigation.get("abnormal_object") or target or "target"
        actions: list[StrategyAction] = []

        if "url_rate_limit" in tags:
            _add_action(
                actions,
                StrategyAction(
                    action_type="url_rate_limit",
                    title="Apply URL rate limiting",
                    rationale=f"Traffic is concentrated on {abnormal_object}.",
                    priority="p0",
                    execution_mode="manual",
                    params={"path": abnormal_object},
                ),
            )
        if "directory_rate_limit" in tags:
            _add_action(
                actions,
                StrategyAction(
                    action_type="directory_rate_limit",
                    title="Apply directory rate limiting",
                    rationale=f"Traffic is concentrated on directory {abnormal_object}.",
                    priority="p1",
                    execution_mode="manual",
                    params={"directory": abnormal_object},
                ),
            )
        if "header_block" in tags:
            _add_action(
                actions,
                StrategyAction(
                    action_type="header_block_rule",
                    title="Add precise header block rule",
                    rationale="Abnormal header pattern is part of the attack evidence.",
                    priority="p0",
                    execution_mode="manual",
                ),
            )
        if "ua_block" in tags:
            _add_action(
                actions,
                StrategyAction(
                    action_type="ua_block_rule",
                    title="Add User-Agent block rule",
                    rationale="Abnormal User-Agent concentration is part of the attack evidence.",
                    priority="p1",
                    execution_mode="manual",
                ),
            )
        if "ip_block_or_cap" in tags:
            _add_action(
                actions,
                StrategyAction(
                    action_type="block_top_offending_ips",
                    title="Block top offending IPs on WAF",
                    rationale="Client IP concentration suggests targeted abuse.",
                    priority="p0",
                    execution_mode="dry_run_ready",
                    tool_name="block_ip_on_waf",
                    params={"reason": likely_cause or "strategy_mapper"},
                ),
            )
        if likely_cause in {"targeted_cc_attack", "edge_absorbed_attack"}:
            _add_action(
                actions,
                StrategyAction(
                    action_type="enable_cc_defense_mode",
                    title="Escalate CC defense mode",
                    rationale="Attack classification indicates layered CC mitigation is appropriate.",
                    priority="p0",
                    execution_mode="dry_run_ready",
                    tool_name="enable_cc_defense_mode",
                    params={"host": target or abnormal_object, "mode": "strict"},
                ),
            )
        if "observe_edge_rules" in tags:
            _add_action(
                actions,
                StrategyAction(
                    action_type="review_edge_rule_hits",
                    title="Review edge rule hit distribution",
                    rationale="Attack may already be absorbed at the edge; rule effectiveness should be verified.",
                    priority="p1",
                    execution_mode="manual",
                ),
            )
        if "customer_origin_check" in tags:
            _add_action(
                actions,
                StrategyAction(
                    action_type="customer_origin_check",
                    title="Check origin health with customer",
                    rationale="Evidence indicates an origin-side issue instead of an active attack.",
                    priority="p0",
                    execution_mode="manual",
                ),
            )

        if not actions:
            _add_action(
                actions,
                StrategyAction(
                    action_type="manual_review",
                    title="Manual review required",
                    rationale="No stable mitigation mapping was available from the current evidence.",
                    priority="p2",
                    execution_mode="manual",
                ),
            )

        titles = ", ".join(action.title for action in actions[:3])
        return StrategyFindings(
            summary=f"Recommended {len(actions)} action(s): {titles}.",
            risk_level=risk_level,
            execution_mode=_max_execution_mode(actions),
            recommended_actions=actions,
            rationale=f"Mapped mitigation tags {sorted(tags)} with cause={likely_cause or 'unknown'}.",
        )
