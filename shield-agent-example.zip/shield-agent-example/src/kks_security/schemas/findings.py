"""
Structured output schemas for worker findings.

Each worker node returns one of these models inside the `findings` dict.
`InvestigationFindings` is reserved for derived cross-worker conclusions.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field


class BaseFindings(BaseModel):
    """Shared runtime-safety contract for all finding objects."""

    collection_status: Literal["complete", "partial", "failed"] = Field(
        default="complete",
        description="Whether evidence collection completed, partially completed, or failed.",
    )
    degraded: bool = Field(
        default=False,
        description="True when the finding was produced through a degraded runtime path.",
    )
    error_code: str | None = Field(
        default=None,
        description="Normalized runtime failure code when degraded=True.",
    )
    error_message: str | None = Field(
        default=None,
        description="Human-readable runtime failure detail when degraded=True.",
    )


class ValueDistributionEvidence(BaseModel):
    """Typed evidence for one dominant value returned by a distribution tool."""

    field_name: str | None = Field(
        default=None,
        description="Source field used for the distribution query.",
    )
    dominant_value: str | None = Field(
        default=None,
        description="Most frequent value in the abnormal window.",
    )
    share: float | None = Field(
        default=None,
        description="Dominant value share as a fraction (0.0-1.0).",
    )
    count: int | None = Field(
        default=None,
        description="Raw count for the dominant value.",
    )
    total_docs: int | None = Field(
        default=None,
        description="Total documents covered by the distribution query.",
    )


class IPURLBindingEvidence(BaseModel):
    """Typed evidence for one client-IP to URL concentration pair."""

    client_ip: str | None = Field(
        default=None,
        description="Client IP of the dominant binding pair.",
    )
    url: str | None = Field(
        default=None,
        description="URL or request path of the dominant binding pair.",
    )
    binding_count: int | None = Field(
        default=None,
        description="Request count for the dominant IP-URL pair.",
    )
    client_ip_total: int | None = Field(
        default=None,
        description="Total request count observed for the client IP.",
    )
    binding_share_within_ip: float | None = Field(
        default=None,
        description="Share of the dominant URL within the client IP request set.",
    )
    binding_share_global: float | None = Field(
        default=None,
        description="Share of the dominant IP-URL pair in the full abnormal window.",
    )


class MachineTrendEvidence(BaseModel):
    """Typed evidence for one machine-side trend query."""

    metric_name: str = Field(description="Stable metric category name.")
    query_used: str | None = Field(
        default=None,
        description="Concrete PromQL expression that returned data, when any.",
    )
    unit: str | None = Field(
        default=None,
        description="Human-readable unit for peak_value, such as connections or seconds.",
    )
    peak_value: float | None = Field(
        default=None,
        description="Highest observed numeric value in the query window.",
    )
    started_at: str | None = Field(
        default=None,
        description="Timestamp when the rising trend likely started.",
    )
    sample_count: int = Field(
        default=0,
        description="Number of time buckets returned by the query.",
    )
    spike_detected: bool | None = Field(
        default=None,
        description="True when the tool detected a sustained or significant rise.",
    )


class LogFindings(BaseFindings):
    """Structured output from the log_detective worker."""

    summary: str = Field(description="Overall log analysis summary")
    qps_info: str = Field(default="No QPS data", description="QPS statistics: avg, peak, trend")
    error_rate: dict[str, Any] = Field(
        default_factory=dict,
        description="Error rate breakdown, e.g. {'4xx': '5%', '5xx': '2%'}",
    )
    top_errors: list[str] = Field(
        default_factory=list,
        description="Top 3-5 errors with status code, URL, and count",
    )
    risk_level: Literal["low", "medium", "high", "critical"] = Field(
        default="medium",
        description="low=normal, medium=slight anomaly, high=clear anomaly, critical=severe fault",
    )
    analysis_text: str = Field(
        default="",
        description="One-sentence summary of tools used and key finding. Max 200 chars.",
    )
    trend_comparison: dict[str, Any] | None = Field(
        default=None,
        description="Historical trend comparison data when trend-comparison tools are used.",
    )
    status_origin: Literal["origin", "edge", "mixed", "unknown"] = Field(
        default="unknown",
        description="Likely origin of abnormal status codes based on upstream evidence.",
    )
    origin_status_codes: list[int] = Field(
        default_factory=list,
        description="Status codes likely generated by the origin side.",
    )
    edge_status_codes: list[int] = Field(
        default_factory=list,
        description="Status codes likely generated by the edge/CDN side.",
    )
    upstream_status_present: bool | None = Field(
        default=None,
        description="Whether upstream_status evidence is present for the abnormal window.",
    )
    upstream_response_length_positive: bool | None = Field(
        default=None,
        description="Whether upstream_response_length > 0 is observed in the abnormal window.",
    )
    error_started_at: str | None = Field(
        default=None,
        description="Timestamp when error growth started, if detected.",
    )
    traffic_started_at: str | None = Field(
        default=None,
        description="Timestamp when traffic growth started, if detected.",
    )
    error_before_traffic: bool | None = Field(
        default=None,
        description="True when error growth started before traffic growth.",
    )
    traffic_before_error: bool | None = Field(
        default=None,
        description="True when traffic growth started before error growth.",
    )
    retry_pattern_suspected: bool | None = Field(
        default=None,
        description="True when the pattern suggests client retries after origin-side errors.",
    )
    targeted_paths: list[str] = Field(
        default_factory=list,
        description="Concentrated abnormal paths observed in the window.",
    )
    targeted_directories: list[str] = Field(
        default_factory=list,
        description="Concentrated abnormal directories observed in the window.",
    )
    single_ip_single_url_burst: bool | None = Field(
        default=None,
        description="True when one IP is heavily concentrated on one URL.",
    )
    dominant_user_agent: ValueDistributionEvidence | None = Field(
        default=None,
        description="Dominant user-agent distribution evidence when collected.",
    )
    dominant_header_value: ValueDistributionEvidence | None = Field(
        default=None,
        description="Dominant suspicious-header distribution evidence when collected.",
    )
    top_ip_url_binding: IPURLBindingEvidence | None = Field(
        default=None,
        description="Top client-IP to URL binding evidence when collected.",
    )
    ua_anomalies: list[str] = Field(
        default_factory=list,
        description="Structured user-agent anomalies observed in the window.",
    )
    header_anomalies: list[str] = Field(
        default_factory=list,
        description="Structured request-header anomalies observed in the window.",
    )
    ip_growth_signals: list[str] = Field(
        default_factory=list,
        description="Structured signals showing abnormal client-IP growth or concentration.",
    )
    rate_5xx: float | None = Field(
        default=None,
        description="5xx error rate as a fraction (0.0-1.0), e.g. 0.02 for 2%.",
    )
    rate_4xx: float | None = Field(
        default=None,
        description="4xx error rate as a fraction (0.0-1.0), e.g. 0.05 for 5%.",
    )


class SecurityFindings(BaseFindings):
    """Structured output from the security_guard worker."""

    summary: str = Field(description="Protection status summary (factual, no attack judgement)")
    cc_status: str = Field(default="unknown", description="CC protection status")
    ddos_status: str = Field(default="unknown", description="DDoS scrubbing status")
    protection_status: str = Field(default="unknown", description="Overall protection evaluation")
    risk_level: Literal["low", "medium", "high", "critical"] = Field(
        default="medium",
        description=(
            "low=protection normal, medium=some rules triggered, "
            "high=heavy triggering, critical=failed"
        ),
    )
    analysis_text: str = Field(default="", description="Tool call chain log")
    cc_is_under_attack: bool | None = Field(
        default=None,
        description="True when CC tool reported is_under_attack=True for any IP.",
    )
    ddos_exceeds_threshold: bool | None = Field(
        default=None,
        description="True when any DDoS event had exceeds_threshold=True.",
    )
    cc_input_pps: int | None = Field(
        default=None,
        description="Highest input_pps value seen across all checked IPs.",
    )
    ddos_event_count: int | None = Field(
        default=None,
        description="Total number of DDoS events returned by the API.",
    )
    operational_issue: Literal["none", "coverage_gap", "integration_or_config_error"] = Field(
        default="none",
        description=(
            "Non-attack operational issue classification for the protection stack: "
            "none | coverage_gap | integration_or_config_error"
        ),
    )
    operational_issue_detail: str = Field(
        default="",
        description="Human-readable detail for coverage or integration/config issues.",
    )


class MachineFindings(BaseFindings):
    """Structured output from the machine_check worker."""

    summary: str = Field(description="Infrastructure check summary")
    connectivity: str = Field(default="unknown", description="Ping/connectivity result")
    system_metrics: str = Field(default="no data", description="CPU/memory/disk summary")
    tcp_status: str = Field(default="no data", description="TCP connection state summary")
    health_status: Literal["healthy", "degraded", "unhealthy"] = Field(
        default="degraded",
        description="healthy=normal, degraded=mild load, unhealthy=severe overload or fault",
    )
    risk_level: Literal["low", "medium", "high", "critical"] = Field(
        default="medium",
        description=(
            "low=system normal, medium=mild pressure, high=overloaded, critical=imminent crash"
        ),
    )
    analysis_text: str = Field(default="", description="Tool call chain log")
    cpu_pct: float | None = Field(
        default=None,
        description="Peak CPU usage fraction (0.0-1.0), e.g. 0.87 for 87%.",
    )
    memory_pct: float | None = Field(
        default=None,
        description="Peak memory usage fraction (0.0-1.0), e.g. 0.64 for 64%.",
    )
    tcp_established: int | None = Field(
        default=None,
        description="Current number of established TCP connections.",
    )
    connection_trend: MachineTrendEvidence | None = Field(
        default=None,
        description="Typed connection-trend evidence when collected.",
    )
    response_time_trend: MachineTrendEvidence | None = Field(
        default=None,
        description="Typed response-time-trend evidence when collected.",
    )
    back_to_origin_trend: MachineTrendEvidence | None = Field(
        default=None,
        description="Typed back-to-origin-trend evidence when collected.",
    )
    connection_spike: bool | None = Field(
        default=None,
        description="True when TCP connection growth is clearly elevated in the window.",
    )
    request_hole: bool | None = Field(
        default=None,
        description="True when connection growth exists but back-to-origin growth does not keep up.",
    )
    response_time_spike: bool | None = Field(
        default=None,
        description="True when response-time metrics spike in the window.",
    )
    back_to_origin_spike: bool | None = Field(
        default=None,
        description="True when back-to-origin request or throughput metrics spike in the window.",
    )


class InvestigationFindings(BaseFindings):
    """Derived cross-worker finding owned by a causality/investigation stage."""

    summary: str = Field(
        default="",
        description="Compact investigation-layer summary derived from worker evidence.",
    )
    risk_level: Literal["low", "medium", "high", "critical"] = Field(
        default="medium",
        description="Derived investigation-layer risk level.",
    )
    abnormal_object: str | None = Field(
        default=None,
        description="Primary abnormal object, e.g. domain, node, path, or origin endpoint.",
    )
    status_origin: Literal["origin", "edge", "mixed", "unknown"] = Field(
        default="unknown",
        description="Where abnormal status codes are generated from.",
    )
    temporal_relation: Literal[
        "error_before_traffic",
        "traffic_before_error",
        "same_window",
        "unknown",
    ] = Field(
        default="unknown",
        description="Temporal relation between traffic growth and error growth.",
    )
    classification: Literal["attack", "non_attack", "unknown"] = Field(
        default="unknown",
        description="Investigation-layer attack classification.",
    )
    likely_cause: str | None = Field(
        default=None,
        description="Short likely-cause label, e.g. targeted_cc_attack or origin_fault.",
    )
    evidence_tags: list[str] = Field(
        default_factory=list,
        description="Structured evidence tags supporting the conclusion.",
    )
    mitigation_tags: list[str] = Field(
        default_factory=list,
        description="Structured mitigation tags mapped from the evidence.",
    )
    rationale: str = Field(
        default="",
        description="Compact rationale derived from typed evidence, not hidden CoT.",
    )


class StrategyAction(BaseModel):
    """One stable mitigation or follow-up action recommendation."""

    action_type: str = Field(description="Stable action identifier.")
    title: str = Field(description="Short operator-facing action title.")
    rationale: str = Field(description="Why this action is recommended.")
    priority: Literal["p0", "p1", "p2"] = Field(
        default="p1",
        description="Priority order for action execution.",
    )
    execution_mode: Literal["manual", "dry_run_ready", "tool_ready"] = Field(
        default="manual",
        description="Whether the action is manual-only or can map to a tool call.",
    )
    tool_name: str | None = Field(
        default=None,
        description="Mapped remediation tool name when available.",
    )
    params: dict[str, Any] = Field(
        default_factory=dict,
        description="JSON-safe tool parameters or structured action context.",
    )


class StrategyFindings(BaseFindings):
    """Derived strategy-layer finding owned by a strategy-mapper stage."""

    summary: str = Field(
        default="",
        description="Compact strategy-layer summary derived from mitigation tags.",
    )
    risk_level: Literal["low", "medium", "high", "critical"] = Field(
        default="medium",
        description="Strategy-layer risk level, usually inherited from investigation.",
    )
    execution_mode: Literal["manual_only", "dry_run_only", "tool_ready"] = Field(
        default="manual_only",
        description="Highest execution readiness among recommended actions.",
    )
    recommended_actions: list[StrategyAction] = Field(
        default_factory=list,
        description="Ordered, stable list of recommended actions.",
    )
    rationale: str = Field(
        default="",
        description="Compact explanation of how mitigation tags mapped to actions.",
    )
