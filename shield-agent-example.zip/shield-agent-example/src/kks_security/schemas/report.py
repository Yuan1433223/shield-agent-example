"""
Report schemas: structured output for the reporter node.

The Feishu surface adapter (`kks_surfaces/feishu/`) is responsible for
translating `InvestigationReport` into delivery-specific payloads.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class PerformanceMetrics(BaseModel):
    """Infrastructure performance snapshot."""

    cpu_usage: str | None = Field(default="unknown", description="CPU usage, for example '45%'.")
    cpu_status: str | None = Field(
        default="normal",
        description="CPU assessment: 'normal' | 'elevated' | 'critical'.",
    )
    memory_usage: str | None = Field(
        default="unknown",
        description="Memory usage, for example '67%'.",
    )
    memory_status: str | None = Field(
        default="normal",
        description="Memory assessment: 'normal' | 'elevated' | 'critical'.",
    )
    disk_io: str | None = Field(default="unknown", description="Disk I/O, for example '23 MB/s'.")
    disk_status: str | None = Field(
        default="normal",
        description="Disk assessment: 'normal' | 'elevated' | 'critical'.",
    )
    tcp_connections: str | None = Field(
        default="unknown",
        description="TCP connection count, for example '1523'.",
    )
    tcp_status: str | None = Field(
        default="normal",
        description="TCP assessment: 'normal' | 'elevated' | 'critical'.",
    )


class NetworkMetrics(BaseModel):
    """Network connectivity snapshot."""

    avg_latency: str | None = Field(default="unknown", description="Average latency, for example '33ms'.")
    packet_loss: str | None = Field(default="unknown", description="Packet loss, for example '0%'.")
    ttl: str | None = Field(default="unknown", description="TTL value, for example '41'.")


class SecurityMetrics(BaseModel):
    """CC/DDoS protection status snapshot."""

    has_cc_attack: bool | None = Field(
        default=None,
        description="True if a CC attack is currently detected.",
    )
    cc_detail: str | None = Field(
        default="no attack detected",
        description="CC attack detail: PPS values, thresholds, and attack flags.",
    )
    has_ddos_attack: bool | None = Field(
        default=None,
        description="True if a DDoS event is detected within the query window.",
    )
    ddos_detail: str | None = Field(
        default="no events recorded",
        description="DDoS event detail: bps values, event count, and threshold comparison.",
    )
    shielded_ip_count: int | None = Field(
        default=0,
        description="Number of IPs currently blocked by the protection system.",
    )
    is_forbidden: bool | None = Field(
        default=False,
        description="True if all traffic to the target is blocked.",
    )
    is_foreign_blocked: bool | None = Field(
        default=False,
        description="True if international traffic is blocked.",
    )


class RequestMetrics(BaseModel):
    """Access-log request analysis snapshot."""

    request_count: str | None = Field(
        default="unknown",
        description="Total request count in the analysis window.",
    )
    request_count_status: str | None = Field(
        default="[requires analysis]",
        description="Whether the request volume is normal, elevated, or anomalous.",
    )
    top_ip: str | None = Field(
        default="not collected",
        description="Top client IP with request count and share.",
    )
    top_ip_status: str | None = Field(
        default="insufficient data",
        description="Assessment of whether the top IP represents normal or suspicious behaviour.",
    )
    top_ua: str | None = Field(
        default="not collected",
        description="Top User-Agent string with request count and share.",
    )
    top_ua_status: str | None = Field(
        default="insufficient data",
        description="Assessment of whether the User-Agent is normal browser traffic.",
    )
    status_code_distribution: str | None = Field(
        default="not collected",
        description="HTTP status code breakdown, for example '200: 80%, 404: 10%, 502: 5%'.",
    )
    status_code_status: str | None = Field(
        default="insufficient data",
        description="Assessment of whether the error-code distribution indicates an attack.",
    )


class InvestigationReport(BaseModel):
    """
    Structured report produced by the reporter node.

    All fields are optional with safe defaults so that partial findings
    still produce a valid report. The explicit investigation-layer fields
    provide a stable contract for UI, Feishu, replay, and later eval work.
    """

    analysis_start: str | None = Field(
        default="unknown",
        description="Start of the analysis window, ISO-8601 or human-readable.",
    )
    analysis_end: str | None = Field(
        default="unknown",
        description="End of the analysis window.",
    )

    alert_status: Literal["normal", "warning", "critical"] | None = Field(
        default="warning",
        description="Overall investigation status.",
    )
    summary: str | None = Field(
        default="[requires analysis]",
        description="One-sentence overall conclusion based on collected findings.",
    )
    recommendations: str | None = Field(
        default="[requires analysis]",
        description="Two to four prioritised, executable recommendations.",
    )

    performance_has_issue: bool = Field(
        default=False,
        description="True if infrastructure shows anomaly.",
    )
    performance_conclusion: str | None = Field(
        default="[requires analysis]",
        description="One-sentence infrastructure health conclusion.",
    )
    performance_metrics: PerformanceMetrics | None = None

    network_has_issue: bool = Field(
        default=False,
        description="True if connectivity shows anomaly.",
    )
    network_conclusion: str | None = Field(
        default="[requires analysis]",
        description="One-sentence network connectivity conclusion.",
    )
    network_metrics: NetworkMetrics | None = None

    security_has_issue: bool = Field(
        default=False,
        description="True if an active attack is detected.",
    )
    security_conclusion: str | None = Field(
        default="[requires analysis]",
        description="One-sentence security protection conclusion.",
    )
    security_metrics: SecurityMetrics | None = None

    request_conclusion: str | None = Field(
        default="[requires analysis]",
        description="One-sentence access-log analysis conclusion.",
    )
    request_metrics: RequestMetrics | None = None

    root_cause: str | None = Field(
        default="[requires analysis]",
        description=(
            "Root-cause analysis. Distinguish between normal load, attack traffic, "
            "infrastructure failure, and configuration issue."
        ),
    )

    abnormal_object: str | None = Field(
        default=None,
        description="Primary abnormal object, such as a path, node, domain, or origin endpoint.",
    )
    status_origin: Literal["origin", "edge", "mixed", "unknown"] | None = Field(
        default="unknown",
        description="Where abnormal statuses are generated from.",
    )
    temporal_relation: Literal[
        "error_before_traffic",
        "traffic_before_error",
        "same_window",
        "unknown",
    ] | None = Field(
        default="unknown",
        description="Temporal relation between error growth and traffic growth.",
    )
    classification: Literal["attack", "non_attack", "unknown"] | None = Field(
        default="unknown",
        description="Stable investigation-layer classification.",
    )
    evidence_tags: list[str] = Field(
        default_factory=list,
        description="Stable evidence tags supporting the investigation conclusion.",
    )
    recommended_action_titles: list[str] = Field(
        default_factory=list,
        description="Stable action titles derived from the strategy layer or recommendations.",
    )
    mitigation_rationale: str | None = Field(
        default="[requires analysis]",
        description="Why a mitigation is recommended, or why no stable mitigation was chosen.",
    )
