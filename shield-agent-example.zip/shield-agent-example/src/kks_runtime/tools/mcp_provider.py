"""MCP tool context manager — always connects to kkshieldhelper-mcp over SSE."""

from __future__ import annotations

from contextlib import asynccontextmanager

from langchain_core.tools import BaseTool


@asynccontextmanager
async def mcp_tool_context(tool_names: frozenset[str]):
    """Yield the subset of MCP tools whose names are in *tool_names*."""
    from kks_runtime.config.settings import get_settings
    from langchain_mcp_adapters.client import MultiServerMCPClient

    s = get_settings()
    server_config = {
        "kks": {
            "url": s.mcp_server_url,
            "transport": "sse",
            "headers": {"Authorization": f"Bearer {s.mcp_auth_token}"},
            "timeout": s.mcp_server_timeout,
        }
    }
    client = MultiServerMCPClient(server_config)
    all_tools: list[BaseTool] = await client.get_tools()
    yield [t for t in all_tools if t.name in tool_names]
