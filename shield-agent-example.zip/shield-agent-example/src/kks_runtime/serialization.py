from __future__ import annotations

from typing import Any

from pydantic_core import to_jsonable_python


def to_jsonable(value: Any) -> Any:
    """Convert runtime values into JSON-safe Python primitives."""

    return to_jsonable_python(value)
