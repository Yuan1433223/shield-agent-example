"""
Reporter node: synthesizes collected findings into an InvestigationReport.

If the report writer fails, the node emits a normalized ErrorEvent and falls
back to a degraded but valid structured report/artifact.
"""

from __future__ import annotations

import logging
from typing import Any

from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.config import get_stream_writer

from kks_runtime.artifacts.investigation import InvestigationArtifact
from kks_runtime.events.errors import build_error_event
from kks_runtime.events.protocol import ArtifactEvent, FinalEvent, StatusEvent
from kks_runtime.llm.profiles import build_model
from kks_runtime.serialization import to_jsonable
from kks_runtime.state.session import SessionState
from kks_security.playbooks.catalog import PlaybookKind, get_playbook
from kks_security.schemas.report import InvestigationReport

logger = logging.getLogger(__name__)

_PLAYBOOK = get_playbook(PlaybookKind.REPORT_GENERATION)
_MAX_VALUE_CHARS = 1_500
_MAX_TOTAL_CHARS = 12_000


async def reporter_node(state: SessionState) -> dict:
    """
    Terminal node: synthesize all findings into an InvestigationReport artifact.

    Emits ArtifactEvent + FinalEvent via stream writer. Surface delivery is
    handled after the graph completes.
    """
    write = get_stream_writer()
    write(StatusEvent(node="reporter", message="Generating investigation report..."))

    findings = state.get("findings", {})
    asset_findings = state.get("asset_findings", {})
    target = state.get("target", "unknown")
    session_id = state.get("session_id", "")

    json_findings = to_jsonable(findings)
    json_asset_findings = to_jsonable(asset_findings)

    findings_text = _format_findings(json_findings)
    asset_findings_text = _format_asset_findings(json_asset_findings)
    degraded = _has_degraded_findings(json_findings, json_asset_findings)

    try:
        user_message = (
            f"Target: {target}\n\n"
            f"Collected findings:\n\n{findings_text}\n\n"
            f"Asset-scoped findings:\n\n{asset_findings_text}\n\n"
            "Generate the investigation report."
        )

        llm = build_model(_PLAYBOOK.model_profile)
        report: InvestigationReport = await llm.with_structured_output(InvestigationReport).ainvoke(
            [
                SystemMessage(content=_PLAYBOOK.system_prompt),
                HumanMessage(content=user_message),
            ]
        )
    except Exception as exc:
        error_event = build_error_event(
            node="reporter",
            stage="report_generation",
            exc=exc,
            degraded=True,
        )
        write(error_event)
        logger.exception("Reporter failed; falling back to degraded report")
        report = _build_degraded_report(
            target=target,
            findings=json_findings,
            asset_findings=json_asset_findings,
            error_message=error_event.message,
        )
        degraded = True

    report = _stabilize_report_contract(report, findings=json_findings, degraded=degraded)

    risk_level = _derive_risk_level(report)
    strategy_recommendations = _strategy_recommendations(json_findings.get("strategy"))
    parsed_recommendations = _parse_recommendations(report.recommendations)
    artifact = InvestigationArtifact(
        session_id=session_id,
        target=target,
        findings=json_findings,
        asset_findings=json_asset_findings,
        report=report.model_dump(mode="json"),
        risk_level=risk_level,
        summary=report.summary or "Investigation complete.",
        recommendations=parsed_recommendations or strategy_recommendations,
        degraded=degraded,
    )

    artifact_dict = artifact.model_dump(mode="json")
    write(ArtifactEvent(artifact_type="investigation", data=artifact_dict))
    write(FinalEvent(findings=json_findings, artifacts=[artifact_dict]))
    write(StatusEvent(node="reporter", message="Report generation complete"))

    return {
        "artifacts": [artifact_dict],
        "status": "completed",
    }


def _build_degraded_report(
    *,
    target: str,
    findings: dict[str, Any],
    asset_findings: dict[str, Any],
    error_message: str,
) -> InvestigationReport:
    """Build a valid fallback report when the report writer fails."""

    summary_parts: list[str] = []
    for key in ("logs", "machine", "security", "investigation"):
        finding = findings.get(key)
        if isinstance(finding, dict) and finding.get("summary"):
            summary_parts.append(f"{key}: {finding['summary']}")

    degraded_detail = (
        "Report generation degraded because the reporter runtime failed. "
        "Use structured findings as the source of truth."
    )
    if summary_parts:
        degraded_detail = f"{degraded_detail} Collected summaries: {' | '.join(summary_parts)}"
    if asset_findings:
        degraded_detail = f"{degraded_detail} Asset-scoped evidence remains available."

    return InvestigationReport(
        alert_status="warning" if not _contains_high_risk(findings, asset_findings) else "critical",
        summary=f"Investigation for {target} completed in degraded mode.",
        recommendations=_degraded_recommendations(findings),
        root_cause=f"{degraded_detail} Reporter error: {error_message}",
        request_conclusion=_finding_summary(findings.get("logs")),
        performance_conclusion=_finding_summary(findings.get("machine")),
        security_conclusion=_finding_summary(findings.get("security")),
        network_conclusion="No dedicated network conclusion available in degraded report.",
    )


def _derive_risk_level(report: InvestigationReport) -> str:
    """Map alert_status to InvestigationArtifact risk_level vocabulary."""

    mapping = {"normal": "low", "warning": "medium", "critical": "high"}
    return mapping.get(report.alert_status or "warning", "medium")


def _stabilize_report_contract(
    report: InvestigationReport,
    *,
    findings: dict[str, Any],
    degraded: bool,
) -> InvestigationReport:
    """Backfill explicit report-contract fields from typed findings when omitted by the LLM."""

    investigation = findings.get("investigation") if isinstance(findings.get("investigation"), dict) else {}
    strategy = findings.get("strategy") if isinstance(findings.get("strategy"), dict) else {}

    updates: dict[str, Any] = {}

    if _is_placeholder(report.abnormal_object):
        abnormal_object = investigation.get("abnormal_object")
        if isinstance(abnormal_object, str) and abnormal_object.strip():
            updates["abnormal_object"] = abnormal_object.strip()

    for field_name in ("status_origin", "temporal_relation", "classification"):
        current = getattr(report, field_name)
        candidate = investigation.get(field_name)
        if current in {None, "unknown"} and candidate not in {None, ""}:
            updates[field_name] = candidate

    if not report.evidence_tags:
        evidence_tags = investigation.get("evidence_tags")
        if isinstance(evidence_tags, list):
            updates["evidence_tags"] = [str(tag).strip() for tag in evidence_tags if str(tag).strip()]

    if not report.recommended_action_titles:
        updates["recommended_action_titles"] = (
            _strategy_recommendations(strategy) or _parse_recommendations(report.recommendations)
        )

    if _is_placeholder(report.mitigation_rationale):
        rationale = _first_nonempty(strategy.get("rationale"), investigation.get("rationale"))
        if rationale:
            updates["mitigation_rationale"] = rationale
        elif updates.get("recommended_action_titles") or report.recommended_action_titles:
            updates["mitigation_rationale"] = "Mitigations were selected from the structured strategy output."

    if degraded:
        degraded_note = "Investigation contains degraded evidence paths; verify conclusions against findings."
        updates["root_cause"] = _append_note(report.root_cause, degraded_note)
        updates["mitigation_rationale"] = _append_note(
            updates.get("mitigation_rationale", report.mitigation_rationale),
            degraded_note,
        )

    return report if not updates else report.model_copy(update=updates)


def _format_findings(findings: dict[str, Any]) -> str:
    """Serialize target-scoped findings into a stable prompt block."""

    if not findings:
        return "No findings collected."
    sections = []
    for key, value in findings.items():
        text = str(value)
        if len(text) > _MAX_VALUE_CHARS:
            text = text[:_MAX_VALUE_CHARS] + "\n...(truncated)"
        sections.append(f"### {key.upper()} FINDINGS\n{text}")
    result = "\n\n".join(sections)
    if len(result) > _MAX_TOTAL_CHARS:
        result = result[:_MAX_TOTAL_CHARS] + "\n\n...(findings truncated; full data in artifacts)"
    return result


def _format_asset_findings(asset_findings: dict[str, Any]) -> str:
    """Serialize asset-scoped findings into a concise prompt block."""

    if not asset_findings:
        return "No asset-scoped findings collected."

    sections: list[str] = []
    for asset_id, payload in asset_findings.items():
        asset = payload.get("asset", {}) if isinstance(payload, dict) else {}
        header = (
            f"{asset_id} | ip={asset.get('ip', 'unknown')} "
            f"type={asset.get('type', 'unknown')} source={asset.get('source', 'unknown')}"
        )
        details = []
        if isinstance(payload, dict):
            for key, value in payload.items():
                if key == "asset":
                    continue
                text = str(value)
                if len(text) > _MAX_VALUE_CHARS:
                    text = text[:_MAX_VALUE_CHARS] + "...(truncated)"
                details.append(f"- {key}: {text}")
        body = "\n".join(details) or "- no worker findings"
        sections.append(f"### {header}\n{body}")
    result = "\n\n".join(sections)
    if len(result) > _MAX_TOTAL_CHARS:
        result = result[:_MAX_TOTAL_CHARS] + "\n\n...(asset findings truncated)"
    return result


def _parse_recommendations(text: str | None) -> list[str]:
    """Split recommendations text into a list of individual items."""

    if not text or text.startswith("["):
        return []
    lines = [line.lstrip("-*0123456789. ").strip() for line in text.splitlines()]
    return [line for line in lines if line]


def _strategy_recommendations(strategy: Any) -> list[str]:
    """Extract plain-text recommendations from structured strategy findings."""

    if not isinstance(strategy, dict):
        return []
    actions = strategy.get("recommended_actions")
    if not isinstance(actions, list):
        return []
    recommendations: list[str] = []
    for action in actions:
        if not isinstance(action, dict):
            continue
        title = action.get("title")
        if isinstance(title, str) and title.strip():
            recommendations.append(title.strip())
    return recommendations


def _degraded_recommendations(findings: dict[str, Any]) -> str:
    """Build degraded recommendations, preferring structured strategy output."""

    strategy_recommendations = _strategy_recommendations(findings.get("strategy"))
    if strategy_recommendations:
        return "\n".join(
            f"{idx + 1}. {item}" for idx, item in enumerate(strategy_recommendations[:3])
        )
    return (
        "1. Review the structured findings and asset_findings directly.\n"
        "2. Re-run reporter generation after resolving the runtime failure.\n"
        "3. Inspect the normalized reporter error for exact failure details."
    )


def _is_placeholder(value: Any) -> bool:
    """Return True when a report field is effectively unset."""

    if value is None:
        return True
    if isinstance(value, str):
        text = value.strip()
        return text == "" or text == "[requires analysis]"
    if isinstance(value, list):
        return len(value) == 0
    return False


def _first_nonempty(*values: Any) -> str | None:
    """Return the first non-placeholder string value."""

    for value in values:
        if isinstance(value, str) and not _is_placeholder(value):
            return value.strip()
    return None


def _append_note(value: str | None, note: str) -> str:
    """Append one note once while preserving existing content."""

    if note in (value or ""):
        return value or note
    if _is_placeholder(value):
        return note
    return f"{value} {note}"


def _has_degraded_findings(findings: dict[str, Any], asset_findings: dict[str, Any]) -> bool:
    """Detect whether any finding object already marks the investigation as degraded."""

    def _iter_dicts(value: Any):
        if isinstance(value, dict):
            yield value
            for nested in value.values():
                yield from _iter_dicts(nested)

    for item in _iter_dicts(findings):
        if item.get("degraded") is True:
            return True
    for item in _iter_dicts(asset_findings):
        if item.get("degraded") is True:
            return True
    return False


def _contains_high_risk(findings: dict[str, Any], asset_findings: dict[str, Any]) -> bool:
    """Check whether any finding carries high or critical risk."""

    def _iter_dicts(value: Any):
        if isinstance(value, dict):
            yield value
            for nested in value.values():
                yield from _iter_dicts(nested)

    for item in _iter_dicts(findings):
        if item.get("risk_level") in {"high", "critical"}:
            return True
    for item in _iter_dicts(asset_findings):
        if item.get("risk_level") in {"high", "critical"}:
            return True
    return False


def _finding_summary(value: Any) -> str:
    """Extract a concise summary from a finding dict for fallback reporting."""

    if isinstance(value, dict):
        summary = value.get("summary")
        if isinstance(summary, str) and summary.strip():
            return summary
    return "[requires analysis]"
