"""Security Guard worker node."""

from __future__ import annotations

from langchain_core.messages import HumanMessage
from langgraph.config import get_stream_writer
from langgraph.prebuilt import create_react_agent

from kks_runtime.events.errors import build_error_event, error_event_as_finding_fields
from kks_runtime.events.protocol import StatusEvent
from kks_runtime.graph.nodes._asset_scope import (
    active_asset,
    build_asset_findings,
    select_primary_asset,
)
from kks_runtime.graph.nodes._tool_tracing import make_traced_tools
from kks_runtime.llm.profiles import ModelProfile, build_model
from kks_runtime.state.session import SessionState
from kks_runtime.tools.mcp_provider import mcp_tool_context
from kks_security.playbooks.catalog import PlaybookKind, get_playbook
from kks_security.policies.evidence import default_policy
from kks_security.schemas.findings import SecurityFindings

_PLAYBOOK = get_playbook(PlaybookKind.ATTACK_ANALYSIS)
_RECURSION_LIMIT = _PLAYBOOK.max_tool_calls * 2 + 1
_SECURITY_GUARD_TOOLS: frozenset[str] = frozenset({
    "check_ddos_status", "check_cc_status", "check_host_status",
    "query_nodes_ip_by_domain", "query_nodes_ip_by_ip", "query_domain_protection_policy",
})


def _annotate_operational_issue(findings: dict) -> None:
    """Mark coverage or integration problems separately from attack severity."""

    text = " ".join(
        str(findings.get(key, ""))
        for key in ("summary", "analysis_text", "cc_status", "ddos_status", "protection_status")
    ).lower()

    if any(
        keyword in text
        for keyword in (
            "misconfiguration",
            "misconfigured",
            "request failed",
            "host check failed",
            "config",
            "invalid key",
        )
    ):
        findings["operational_issue"] = "integration_or_config_error"
        findings["operational_issue_detail"] = (
            "Security integrations returned configuration or connectivity errors."
        )
        return

    if (
        findings.get("protection_status") in {"incomplete", "degraded"}
        or findings.get("cc_status") in {"no_data", "not_applicable"}
        or findings.get("ddos_status") in {"no_data", "not_applicable"}
    ):
        findings["operational_issue"] = "coverage_gap"
        findings["operational_issue_detail"] = (
            "Security coverage is incomplete or telemetry is missing for this target."
        )
        return

    findings["operational_issue"] = "none"
    findings["operational_issue_detail"] = ""


async def security_guard_node(state: SessionState) -> dict:
    """Worker node: check CC/DDoS protection status via security APIs."""

    write = get_stream_writer()
    write(StatusEvent(node="security_guard", message="正在检查 CC/DDoS 防护状态..."))

    task = state.get("agent_task") or f"Check security protection for {state.get('target', 'unknown')}"
    scoped_asset = active_asset(state)
    primary_asset = scoped_asset or select_primary_asset(
        state,
        capability_scope_key="security",
        required_capabilities=("cc", "ddos"),
    )

    try:
        llm = build_model(_PLAYBOOK.model_profile)
        async with mcp_tool_context(_SECURITY_GUARD_TOOLS) as tools:
            traced_tools = make_traced_tools(tools, "security_guard")
            agent = create_react_agent(model=llm, tools=traced_tools, prompt=_PLAYBOOK.system_prompt)
            resp = await agent.ainvoke(
                {"messages": [HumanMessage(content=task)]},
                config={"recursion_limit": _RECURSION_LIMIT},
            )
        analysis_text: str = resp["messages"][-1].content

        extractor = build_model(ModelProfile.STRUCTURED_EXTRACTOR)
        findings: SecurityFindings = await extractor.with_structured_output(
            SecurityFindings
        ).ainvoke(
            "从以下防护状态分析结果中提取结构化 security findings：\n\n"
            f"{analysis_text}"
        )

        findings_dict = findings.model_dump(mode="json")
        findings_dict["risk_level"] = default_policy().classify_security(findings_dict)
        _annotate_operational_issue(findings_dict)
        write(StatusEvent(node="security_guard", message="安全检查完成"))

        result = {
            "messages": resp["messages"],
            "asset_findings": build_asset_findings(
                primary_asset,
                finding_key="security",
                finding_value=findings_dict,
            ),
        }
        if scoped_asset is None:
            result["findings"] = {"security": findings_dict}
        return result
    except Exception as exc:
        error_event = build_error_event(
            node="security_guard",
            stage="security_analysis",
            exc=exc,
            degraded=True,
        )
        write(error_event)
        degraded_findings = SecurityFindings(
            summary="Security analysis degraded due to runtime failure.",
            risk_level="medium",
            analysis_text="",
            protection_status="degraded",
            **error_event_as_finding_fields(error_event),
        ).model_dump(mode="json")
        _annotate_operational_issue(degraded_findings)
        result = {
            "asset_findings": build_asset_findings(
                primary_asset,
                finding_key="security",
                finding_value=degraded_findings,
            ),
        }
        if scoped_asset is None:
            result["findings"] = {"security": degraded_findings}
        return result
