"""
Asset Resolution node.

Resolves a raw target (IP or domain) into typed NodeMachine assets consumed by
the runtime for capability-safe routing.
"""

from __future__ import annotations

import json
import logging
import re
from typing import Any

from langchain_core.tools.base import ToolException

from kks_runtime.state.session import SessionState
from kks_security.assets.capabilities import build_capability_scope
from kks_security.schemas.node_machine import NodeMachine

logger = logging.getLogger(__name__)


def _unwrap_mcp(result: Any) -> Any:
    """Parse langchain-mcp-adapters content-block format into a Python native value.

    Some MCP servers return [{'type': 'text', 'text': '<json>'}] instead of a
    parsed dict/list.  This unwraps that envelope so callers can work with plain
    Python types regardless of server version.
    """
    if isinstance(result, list) and result and isinstance(result[0], dict):
        if result[0].get("type") == "text":
            try:
                return json.loads(result[0]["text"])
            except (json.JSONDecodeError, KeyError):
                return result[0].get("text", "")
    return result

_IPV4_RE = re.compile(r"^\d{1,3}(\.\d{1,3}){3}$")


def _is_ip(target: str) -> bool:
    return bool(_IPV4_RE.match(target.strip()))


def _machines_from_resolver_data(
    source: str,
    data: dict | list | None,
    *,
    origin_target: str,
    target_type: str,
) -> list[NodeMachine]:
    if not data:
        return []
    items = data if isinstance(data, list) else [data]
    machines: list[NodeMachine] = []
    for item in items:
        node_ip = item.get("node_ip")
        # handle both 'ip_list' and 'business_ip' key names
        ip_list = item.get("ip_list") or item.get("business_ip") or []
        if node_ip:
            machines.append(
                NodeMachine.build(
                    ip=node_ip,
                    node_type="node_product",
                    source=source,
                    origin_target=origin_target,
                    target_type=target_type,
                )
            )
        for ip in ip_list:
            if ip and ip != node_ip:
                machines.append(
                    NodeMachine.build(
                        ip=ip,
                        node_type="product",
                        source=source,
                        origin_target=origin_target,
                        target_type=target_type,
                    )
                )
    return machines


def _split_scope(machines: list[NodeMachine]) -> tuple[list[str], list[str]]:
    node_ips: list[str] = []
    product_ips: list[str] = []
    for machine in machines:
        if "prom" in machine.capabilities:
            node_ips.append(machine.ip)
        if "cc" in machine.capabilities or "ddos" in machine.capabilities:
            product_ips.append(machine.ip)
    return node_ips, product_ips


async def asset_resolution_node(state: SessionState) -> dict:
    """
    Resolve the raw target into typed NodeMachine assets.

    Always returns the full resolution bundle so later nodes can rely on a
    stable state shape from their first invocation onward.
    """
    from kks_runtime.config.settings import get_settings
    from langchain_mcp_adapters.client import MultiServerMCPClient

    target = state.get("target", "").strip()
    s = get_settings()
    server_config = {
        "kks": {
            "url": s.mcp_server_url,
            "transport": "sse",
            "headers": {"Authorization": f"Bearer {s.mcp_auth_token}"},
            "timeout": s.mcp_server_timeout,
        }
    }

    client = MultiServerMCPClient(server_config)
    _tools = {t.name: t for t in await client.get_tools()}

    if _is_ip(target):
        target_type = "ip"
        machines = await _resolve_ip(target, _tools)
        resolution_reason = (
            "resolved_from_ip_lookup"
            if machines and machines[0].is_resolved
            else "unresolved_ip_fallback"
        )
    else:
        target_type = "domain"
        machines = await _resolve_domain(target, _tools)
        resolution_reason = "resolved_from_domain_lookup" if machines else "unresolved_domain"

    source_type = machines[0].source if machines else None
    node_ips, product_ips = _split_scope(machines)
    capability_scope = build_capability_scope(
        ((machine.asset_id, machine.capabilities) for machine in machines),
        domain_policy=(target_type == "domain"),
    )

    return {
        "target_type": target_type,
        "resolved_target": target,
        "source_type": source_type,
        "resolution_reason": resolution_reason,
        "node_ips": node_ips,
        "product_ips": product_ips,
        "capability_scope": capability_scope,
        "inspection_scope": [machine.model_dump() for machine in machines],
    }


async def _resolve_ip(ip: str, tools: dict) -> list[NodeMachine]:
    try:
        result = _unwrap_mcp(await tools["query_nodes_ip_by_ip"].ainvoke({"ip": ip}))
    except (ToolException, Exception) as exc:
        logger.warning("query_nodes_ip_by_ip failed for %s: %s", ip, exc)
        result = None
    if result and isinstance(result, dict) and result.get("node_ip"):
        try:
            src_raw = await tools["query_domain_source"].ainvoke({"domain": ip})
            src_result = _unwrap_mcp(src_raw)
        except (ToolException, Exception):
            src_result = {}
        source = (src_result.get("source") or "GF") if isinstance(src_result, dict) else "GF"
        return _machines_from_resolver_data(
            source, result, origin_target=ip, target_type="ip"
        )
    return [
        NodeMachine.build(
            ip=ip,
            node_type="node",
            source=None,
            origin_target=ip,
            target_type="ip",
            is_resolved=False,
            labels=["standalone"],
        )
    ]


async def _resolve_domain(domain: str, tools: dict) -> list[NodeMachine]:
    try:
        src_raw = await tools["query_domain_source"].ainvoke({"domain": domain})
        src_result = _unwrap_mcp(src_raw)
    except (ToolException, Exception) as exc:
        logger.warning("query_domain_source failed for %s: %s", domain, exc)
        src_result = {}
    source = (src_result.get("source") or "GF") if isinstance(src_result, dict) else "GF"

    try:
        nodes_raw = await tools["query_nodes_ip_by_domain"].ainvoke({"domain": domain})
        nodes_result = _unwrap_mcp(nodes_raw)
    except (ToolException, Exception) as exc:
        logger.warning("query_nodes_ip_by_domain failed for %s: %s", domain, exc)
        nodes_result = None

    if nodes_result and isinstance(nodes_result, list):
        return _machines_from_resolver_data(
            source, nodes_result, origin_target=domain, target_type="domain"
        )
    return []
