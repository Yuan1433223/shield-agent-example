"""
Supervisor node.

Routes deterministically based on missing findings and resolved capability
scope. The LLM only writes the contextual task instruction.
"""

from __future__ import annotations

from typing import Literal

from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.config import get_stream_writer
from pydantic import BaseModel, Field

from kks_runtime.events.protocol import ApprovalRequestEvent, StatusEvent
from kks_runtime.graph.nodes.asset_resolution import _is_ip as _is_ip
from kks_runtime.llm.profiles import build_model
from kks_runtime.state.session import SessionState
from kks_security.playbooks.catalog import PlaybookKind, get_playbook
from kks_security.policies.evidence import default_policy

_PLAYBOOK = get_playbook(PlaybookKind.ALERT_TRIAGE)

_AVAILABLE_WORKERS = Literal[
    "log_detective",
    "machine_check",
    "security_guard",
    "causality_judge",
    "strategy_mapper",
    "reporter",
]

_WORKER_FINDINGS: dict[str, frozenset[str]] = {
    "log_detective": frozenset(get_playbook(PlaybookKind.LOG_ANALYSIS).required_findings),
    "machine_check": frozenset(get_playbook(PlaybookKind.INFRA_DIAGNOSIS).required_findings),
    "security_guard": frozenset(get_playbook(PlaybookKind.ATTACK_ANALYSIS).required_findings),
}

_DISPATCH_ORDER: list[str] = ["log_detective", "machine_check", "security_guard"]

_WORKER_FINDING_KEY: dict[str, str] = {
    "log_detective": "logs",
    "machine_check": "machine",
    "security_guard": "security",
    "causality_judge": "investigation",
    "strategy_mapper": "strategy",
}


def _phase_summary(findings: dict, eligible_workers: frozenset[str], next_node: str) -> str:
    """Build a one-line evidence-progress summary for operators."""

    parts: list[str] = []
    for worker, key in _WORKER_FINDING_KEY.items():
        if key in findings:
            status = "done"
        elif worker in eligible_workers or worker == next_node:
            status = "pending"
        else:
            status = "n/a"
        parts.append(f"{key}={status}")
    return "evidence: " + "  ".join(parts) + f"  -> {next_node}"


class AgentTaskDecision(BaseModel):
    """LLM output: contextual task instruction for the chosen worker node."""

    agent_task: str = Field(
        description=(
            "Specific, one-sentence task instruction for the worker node. "
            "Include the target name and what aspect to focus on."
        )
    )


def _eligible_workers(capability_scope: dict[str, list[str]] | None) -> frozenset[str]:
    """
    Map resolved asset capabilities to the workers allowed in this session.

    `log_detective` always stays enabled because every investigation needs a log
    view of the target. `machine_check` and `security_guard` depend on scope.
    """

    scope = capability_scope or {}
    allowed = {"log_detective"}
    if scope.get("machine"):
        allowed.add("machine_check")
    if scope.get("security"):
        allowed.add("security_guard")
    return frozenset(allowed)


def _next_worker(
    findings: dict,
    eligible_workers: frozenset[str] | None = None,
    *,
    is_ip_target: bool | None = None,
) -> str:
    """Return the next worker, the causality stage, or `reporter`."""

    if eligible_workers is None:
        eligible_workers = frozenset(
            {"log_detective", "security_guard", "machine_check"}
            if is_ip_target
            else {"log_detective", "security_guard"}
        )

    for worker in _DISPATCH_ORDER:
        if worker not in eligible_workers:
            continue
        required = _WORKER_FINDINGS[worker]
        if not required.issubset(findings.keys()):
            return worker

    if "investigation" not in findings:
        return "causality_judge"
    if "strategy" not in findings:
        return "strategy_mapper"
    return "reporter"


async def supervisor_node(state: SessionState) -> dict:
    """Orchestrator node: route to the next worker, approval gate, or reporter."""

    target = state.get("target", "unknown")
    findings = state.get("findings", {})
    messages = state.get("messages", [])
    target_type = state.get("target_type", "domain")
    eligible_workers = _eligible_workers(state.get("capability_scope"))

    next_node = _next_worker(findings, eligible_workers)

    try:
        write = get_stream_writer()
    except RuntimeError:
        write = lambda _event: None
    write(StatusEvent(node="supervisor", message=_phase_summary(findings, eligible_workers, next_node)))

    if next_node == "reporter":
        policy = default_policy()
        if policy.requires_approval(findings):
            session_id = state.get("session_id", "")
            write(ApprovalRequestEvent(session_id=session_id, findings=findings))
            next_node = "approval_gate"

    task_prompt = (
        f"目标: {target} ({'IP 地址' if target_type == 'ip' else '域名'})\n"
        f"已解析来源: {state.get('source_type') or '未知'}\n"
        f"可用专家: {sorted(eligible_workers)}\n"
        f"下一步交给: {next_node}\n"
        f"已收集数据维度: {list(findings.keys()) or '（无）'}\n"
        f"当前对话轮次: {len(messages)}\n\n"
        f"请为 {next_node} 写一句简明具体的任务指令，包含目标名称和分析重点。"
    )
    llm = build_model(_PLAYBOOK.model_profile)
    decision: AgentTaskDecision = await llm.with_structured_output(AgentTaskDecision).ainvoke(
        [
            SystemMessage(content=_PLAYBOOK.system_prompt),
            HumanMessage(content=task_prompt),
        ]
    )

    return {
        "next_node": next_node,
        "agent_task": decision.agent_task,
        "status": "waiting_approval" if next_node == "approval_gate" else "running",
    }
