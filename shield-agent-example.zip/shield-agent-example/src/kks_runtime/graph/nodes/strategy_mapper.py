"""Strategy mapper node: derive stable action recommendations from investigation findings."""

from __future__ import annotations

from langgraph.config import get_stream_writer

from kks_runtime.events.protocol import StatusEvent
from kks_runtime.state.session import SessionState
from kks_security.policies.strategy import StrategyMapperPolicy


async def strategy_mapper_node(state: SessionState) -> dict:
    """Derive `findings["strategy"]` from `findings["investigation"]`."""

    try:
        write = get_stream_writer()
    except RuntimeError:
        write = lambda _event: None

    write(StatusEvent(node="strategy_mapper", message="Mapping mitigation strategy..."))
    findings = state.get("findings", {})
    policy = StrategyMapperPolicy()
    strategy = policy.map(findings.get("investigation"), target=state.get("target"))
    write(StatusEvent(node="strategy_mapper", message="Strategy mapping complete"))
    return {"findings": {"strategy": strategy.model_dump(mode="json")}}
