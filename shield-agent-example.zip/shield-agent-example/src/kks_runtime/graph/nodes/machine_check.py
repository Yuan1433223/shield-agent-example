"""Machine Check worker node."""

from __future__ import annotations

from langchain_core.messages import HumanMessage
from langgraph.config import get_stream_writer
from langgraph.prebuilt import create_react_agent

from kks_runtime.events.errors import build_error_event, error_event_as_finding_fields
from kks_runtime.events.protocol import StatusEvent
from kks_runtime.graph.nodes._asset_scope import (
    active_asset,
    build_asset_findings,
    select_primary_asset,
)
from kks_runtime.graph.nodes._extraction_context import build_extraction_context
from kks_runtime.graph.nodes._tool_tracing import make_traced_tools
from kks_runtime.llm.profiles import ModelProfile, build_model
from kks_runtime.state.session import SessionState
from kks_runtime.tools.mcp_provider import mcp_tool_context
from kks_security.playbooks.catalog import PlaybookKind, get_playbook
from kks_security.policies.evidence import default_policy
from kks_security.schemas.findings import MachineFindings

_MACHINE_CHECK_TOOLS: frozenset[str] = frozenset({
    "query_instance_uname", "query_instance_cpu", "query_instance_memory",
    "query_instance_disk", "query_instance_tcp", "query_instance_socket",
    "query_instance_network_bandwidth", "query_instance_status",
    "query_instance_metrics_trend", "get_now_time", "check_connection_status",
})

_PLAYBOOK = get_playbook(PlaybookKind.INFRA_DIAGNOSIS)
_RECURSION_LIMIT = _PLAYBOOK.max_tool_calls * 2 + 1
_EXTRACTION_PROMPT = """从以下基础设施分析结果中提取结构化 findings。

优先填充类型化证据字段而非散文。当分析包含趋势证据时，尽量填写：
- cpu_pct（CPU 峰值使用率，数值型）
- memory_pct（内存峰值使用率，数值型）
- tcp_established（TCP 已建立连接数峰值）
- connection_trend（连接数趋势数据）
- response_time_trend（响应时间趋势数据）
- back_to_origin_trend（回源请求趋势数据）
- connection_spike（是否检测到连接数尖峰）
- request_hole（是否存在"连接有但回源无"的请求空洞）
- response_time_spike（是否检测到响应时间尖峰）
- back_to_origin_spike（是否检测到回源尖峰）

趋势证据的数值保留原始小数或数字，不写成格式化散文。

若某字段无证据支撑，留为 null、unknown 或空值。
"""


def _sample_count(evidence: object) -> int:
    if isinstance(evidence, dict):
        return int(evidence.get("sample_count") or 0)
    return 0


def _spike_flag(evidence: object) -> bool | None:
    if isinstance(evidence, dict):
        flag = evidence.get("spike_detected")
        if isinstance(flag, bool):
            return flag
    return None


def _backfill_machine_signals(findings: dict) -> None:
    """Derive stable booleans from typed trend evidence when extractor omitted them."""
    connection_trend = findings.get("connection_trend")
    response_time_trend = findings.get("response_time_trend")
    back_to_origin_trend = findings.get("back_to_origin_trend")

    if findings.get("connection_spike") is None:
        findings["connection_spike"] = _spike_flag(connection_trend)
    if findings.get("response_time_spike") is None:
        findings["response_time_spike"] = _spike_flag(response_time_trend)
    if findings.get("back_to_origin_spike") is None:
        findings["back_to_origin_spike"] = _spike_flag(back_to_origin_trend)

    if (
        findings.get("request_hole") is None
        and _sample_count(back_to_origin_trend) > 0
        and isinstance(findings.get("connection_spike"), bool)
        and isinstance(findings.get("back_to_origin_spike"), bool)
    ):
        findings["request_hole"] = (
            findings["connection_spike"] is True and findings["back_to_origin_spike"] is False
        )


async def machine_check_node(state: SessionState) -> dict:
    """Worker node: assess infrastructure health via Prometheus metrics."""

    write = get_stream_writer()
    write(StatusEvent(node="machine_check", message="正在查询基础设施指标..."))

    task = state.get("agent_task") or f"Check infrastructure for {state.get('target', 'unknown')}"
    scoped_asset = active_asset(state)
    primary_asset = scoped_asset or select_primary_asset(
        state,
        capability_scope_key="machine",
        required_capabilities=("prom",),
    )

    try:
        llm = build_model(_PLAYBOOK.model_profile)
        async with mcp_tool_context(_MACHINE_CHECK_TOOLS) as tools:
            traced_tools = make_traced_tools(tools, "machine_check")
            agent = create_react_agent(model=llm, tools=traced_tools, prompt=_PLAYBOOK.system_prompt)

            resp = await agent.ainvoke(
                {"messages": [HumanMessage(content=task)]},
                config={"recursion_limit": _RECURSION_LIMIT},
            )
        analysis_text: str = resp["messages"][-1].content
        extraction_context = build_extraction_context(resp["messages"])

        extractor = build_model(ModelProfile.STRUCTURED_EXTRACTOR)
        findings: MachineFindings = await extractor.with_structured_output(
            MachineFindings
        ).ainvoke(
            (
                f"{_EXTRACTION_PROMPT}\n\n"
                f"Final analysis summary:\n{analysis_text}\n\n"
                f"Tool trace and analysis context:\n{extraction_context}"
            )
        )

        findings_dict = findings.model_dump(mode="json")
        _backfill_machine_signals(findings_dict)
        findings_dict["risk_level"] = default_policy().classify_machine(findings_dict)
        write(StatusEvent(node="machine_check", message="基础设施巡检完成"))

        result = {
            "messages": resp["messages"],
            "asset_findings": build_asset_findings(
                primary_asset,
                finding_key="machine",
                finding_value=findings_dict,
            ),
        }
        if scoped_asset is None:
            result["findings"] = {"machine": findings_dict}
        return result
    except Exception as exc:
        error_event = build_error_event(
            node="machine_check",
            stage="machine_analysis",
            exc=exc,
            degraded=True,
        )
        write(error_event)
        degraded_findings = MachineFindings(
            summary="Machine analysis degraded due to runtime failure.",
            health_status="degraded",
            risk_level="medium",
            analysis_text="",
            **error_event_as_finding_fields(error_event),
        ).model_dump(mode="json")
        result = {
            "asset_findings": build_asset_findings(
                primary_asset,
                finding_key="machine",
                finding_value=degraded_findings,
            ),
        }
        if scoped_asset is None:
            result["findings"] = {"machine": degraded_findings}
        return result
