"""Helpers for building structured-extraction context from agent messages."""

from __future__ import annotations

import json

_TOOL_RESULT_MAX_CHARS = 600
_CONTEXT_MAX_CHARS = 6000


def render_message_content(content: object) -> str:
    """Best-effort renderer for LangChain message content."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        rendered_parts: list[str] = []
        for part in content:
            if isinstance(part, str):
                rendered_parts.append(part)
            elif isinstance(part, dict) and part.get("type") == "text":
                rendered_parts.append(str(part.get("text", "")))
            else:
                rendered_parts.append(json.dumps(part, ensure_ascii=False, default=str))
        return "\n".join(part for part in rendered_parts if part)
    if content is None:
        return ""
    return json.dumps(content, ensure_ascii=False, default=str)


def build_extraction_context(messages: list[object]) -> str:
    """Flatten tool outputs and final analysis messages into one extractor context.

    Tool results are truncated to _TOOL_RESULT_MAX_CHARS each to avoid feeding
    raw ES blobs into the structured extractor. The final analysis messages
    (the agent's own reasoning) are kept in full as they contain the conclusions.
    The total context is also capped at _CONTEXT_MAX_CHARS.
    """
    tool_blocks: list[str] = []
    analysis_blocks: list[str] = []

    for message in messages:
        message_type = getattr(message, "type", message.__class__.__name__).lower()
        if message_type == "tool":
            tool_name = getattr(message, "name", None) or "unknown_tool"
            content = render_message_content(getattr(message, "content", ""))
            if content:
                if len(content) > _TOOL_RESULT_MAX_CHARS:
                    content = content[:_TOOL_RESULT_MAX_CHARS] + f"...[truncated {len(content)} chars]"
                tool_blocks.append(f"[tool:{tool_name}]\n{content}")
            continue
        if message_type == "ai" and not getattr(message, "tool_calls", None):
            content = render_message_content(getattr(message, "content", ""))
            if content:
                analysis_blocks.append(f"[analysis]\n{content}")

    # Put analysis first (most valuable for extraction), then tool evidence
    blocks = analysis_blocks + tool_blocks
    result = "\n\n".join(blocks)
    if len(result) > _CONTEXT_MAX_CHARS:
        result = result[:_CONTEXT_MAX_CHARS] + f"\n...[context truncated at {_CONTEXT_MAX_CHARS} chars]"
    return result
