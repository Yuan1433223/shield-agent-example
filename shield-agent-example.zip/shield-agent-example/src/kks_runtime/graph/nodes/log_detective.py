"""Log Detective worker node."""

from __future__ import annotations

from langchain_core.messages import HumanMessage
from langgraph.config import get_stream_writer
from langgraph.prebuilt import create_react_agent

from kks_runtime.events.errors import build_error_event, error_event_as_finding_fields
from kks_runtime.events.protocol import StatusEvent
from kks_runtime.graph.nodes._extraction_context import build_extraction_context
from kks_runtime.graph.nodes._tool_tracing import make_traced_tools
from kks_runtime.llm.profiles import ModelProfile, build_model
from kks_runtime.state.session import SessionState
from kks_runtime.tools.mcp_provider import mcp_tool_context
from kks_security.playbooks.catalog import PlaybookKind, get_playbook
from kks_security.policies.evidence import default_policy
from kks_security.schemas.findings import LogFindings

_PLAYBOOK = get_playbook(PlaybookKind.LOG_ANALYSIS)
_RECURSION_LIMIT = _PLAYBOOK.max_tool_calls * 2 + 1
_LOG_DETECTIVE_TOOLS: frozenset[str] = frozenset({
    # Asset resolution — must run first for domain targets
    "get_now_time", "query_domain_source", "query_nodes_ip_by_domain",
    # ES queries
    "query_es_raw_logs", "query_es_unique_count", "query_es_top_n",
    "query_es_qps_trend", "query_es_unique_trend", "query_es_status_code_trend",
    "query_es_top_n_trend", "query_request_count", "query_status_code_distribution",
    "query_nodes_request_stats", "check_security_alarms",
    "query_status_origin_breakdown", "query_error_traffic_timeline",
    "query_targeted_path_patterns", "query_header_value_distribution",
    "query_ip_url_binding", "query_es_trend_comparison",
    "query_customer_business_desc",
    "search_knowledge", "get_gf_log_table_structure", "get_waf_log_table_structure",
})
_EXTRACTION_PROMPT = """从以下日志分析结果中提取结构化 findings。

优先填充类型化证据字段而非散文。当分析包含错误来源或时序证据时，尽量填写：
- status_origin（错误来源：origin / edge / mixed / unknown）
- origin_status_codes（源站生成的状态码列表）
- edge_status_codes（边缘节点生成的状态码列表）
- upstream_status_present（是否存在 upstream_status 字段）
- upstream_response_length_positive（upstream_response_length 是否大于 0）
- error_started_at（错误首次出现时间）
- traffic_started_at（流量增长起始时间）
- error_before_traffic（错误是否早于流量增长）
- traffic_before_error（流量是否早于错误增长）
- retry_pattern_suspected（是否怀疑存在重试风暴）
- targeted_paths（高集中度路径列表）
- targeted_directories（高集中度目录列表）
- single_ip_single_url_burst（是否存在单 IP 集中打单 URL 的爆发模式）
- dominant_user_agent（占比最高的 User-Agent）
- dominant_header_value（占比最高的请求头值）
- top_ip_url_binding（Top IP-URL 绑定对）
- ua_anomalies（UA 异常标志）
- header_anomalies（请求头异常标志）
- ip_growth_signals（攻击源 IP 增长信号）

分布或绑定证据的份额用小数保留（例如 0.65 而非 65%）。

若某字段无证据支撑，留为 null、unknown 或空值。
"""


async def log_detective_node(state: SessionState) -> dict:
    """Worker node: analyze ES access logs for the investigation target."""

    write = get_stream_writer()
    write(StatusEvent(node="log_detective", message="正在分析访问日志..."))

    task = state.get("agent_task") or f"Analyse logs for {state.get('target', 'unknown')}"

    try:
        llm = build_model(_PLAYBOOK.model_profile)
        async with mcp_tool_context(_LOG_DETECTIVE_TOOLS) as tools:
            traced_tools = make_traced_tools(tools, "log_detective")
            agent = create_react_agent(
                model=llm,
                tools=traced_tools,
                prompt=_PLAYBOOK.system_prompt,
            )

            resp = await agent.ainvoke(
                {"messages": [HumanMessage(content=task)]},
                config={"recursion_limit": _RECURSION_LIMIT},
            )
        analysis_text: str = resp["messages"][-1].content
        extraction_context = build_extraction_context(resp["messages"])

        extractor = build_model(ModelProfile.STRUCTURED_EXTRACTOR)
        findings: LogFindings = await extractor.with_structured_output(LogFindings).ainvoke(
            (
                f"{_EXTRACTION_PROMPT}\n\n"
                f"Final analysis summary:\n{analysis_text}\n\n"
                f"Tool trace and analysis context:\n{extraction_context}"
            )
        )

        findings_dict = findings.model_dump(mode="json")
        findings_dict["risk_level"] = default_policy().classify_logs(findings_dict)

        write(StatusEvent(node="log_detective", message="日志分析完成"))
        return {
            "messages": resp["messages"],
            "findings": {"logs": findings_dict},
        }
    except Exception as exc:
        error_event = build_error_event(
            node="log_detective",
            stage="log_analysis",
            exc=exc,
            degraded=True,
        )
        write(error_event)
        degraded_findings = LogFindings(
            summary="Log analysis degraded due to runtime failure.",
            risk_level="medium",
            analysis_text="",
            **error_event_as_finding_fields(error_event),
        ).model_dump(mode="json")
        return {"findings": {"logs": degraded_findings}}
