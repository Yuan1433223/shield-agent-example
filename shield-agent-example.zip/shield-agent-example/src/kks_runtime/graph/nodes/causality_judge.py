"""Causality judge node: derive investigation-layer findings from worker evidence."""

from __future__ import annotations

from langgraph.config import get_stream_writer

from kks_runtime.events.protocol import StatusEvent
from kks_runtime.state.session import SessionState
from kks_security.policies.causality import CausalityPolicy


async def causality_judge_node(state: SessionState) -> dict:
    """Derive `findings["investigation"]` from collected worker evidence."""

    try:
        write = get_stream_writer()
    except RuntimeError:
        write = lambda _event: None
    write(StatusEvent(node="causality_judge", message="Deriving causality judgement..."))

    findings = state.get("findings", {})
    policy = CausalityPolicy()
    investigation = policy.evaluate(
        logs=findings.get("logs"),
        machine=findings.get("machine"),
        security=findings.get("security"),
        abnormal_object=state.get("target"),
    )

    write(StatusEvent(node="causality_judge", message="Causality judgement complete"))
    return {"findings": {"investigation": investigation.model_dump(mode="json")}}
