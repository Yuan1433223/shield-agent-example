from __future__ import annotations

from typing import Annotated, Any, Literal

from pydantic import BaseModel, Field


class StatusEvent(BaseModel):
    type: Literal["status"] = "status"
    node: str
    message: str


class ToolCallEvent(BaseModel):
    type: Literal["tool_call"] = "tool_call"
    node: str
    tool_name: str
    tool_input: dict[str, Any]


class ToolResultEvent(BaseModel):
    type: Literal["tool_result"] = "tool_result"
    node: str
    tool_name: str
    output: Any


class ArtifactEvent(BaseModel):
    type: Literal["artifact"] = "artifact"
    artifact_type: str
    data: dict[str, Any]


class FinalEvent(BaseModel):
    type: Literal["final"] = "final"
    findings: dict[str, Any]
    artifacts: list[dict[str, Any]]


class ErrorEvent(BaseModel):
    type: Literal["error"] = "error"
    message: str
    node: str | None = None
    error_code: str | None = None
    stage: str | None = None
    retryable: bool = False
    degraded: bool = True
    tool_name: str | None = None


class ApprovalRequestEvent(BaseModel):
    """Emitted by supervisor when a critical finding requires human approval."""

    type: Literal["approval_request"] = "approval_request"
    session_id: str
    findings: dict[str, Any]


class ApprovalDecisionEvent(BaseModel):
    """Emitted by the approval gate after the human responds."""

    type: Literal["approval_decision"] = "approval_decision"
    session_id: str
    approved: bool
    approver: str


RuntimeEvent = Annotated[
    StatusEvent
    | ToolCallEvent
    | ToolResultEvent
    | ArtifactEvent
    | FinalEvent
    | ErrorEvent
    | ApprovalRequestEvent
    | ApprovalDecisionEvent,
    Field(discriminator="type"),
]
