from __future__ import annotations

from typing import Any

from kks_runtime.events.protocol import ErrorEvent

_RETRYABLE_EXCEPTION_NAMES = {
    "TimeoutError",
    "ConnectTimeout",
    "ReadTimeout",
    "APITimeoutError",
    "RateLimitError",
}


def build_error_event(
    *,
    message: str | None = None,
    node: str | None = None,
    stage: str | None = None,
    exc: Exception | None = None,
    error_code: str | None = None,
    retryable: bool | None = None,
    degraded: bool = True,
    tool_name: str | None = None,
) -> ErrorEvent:
    """Build a normalized runtime error event from a node/tool failure."""

    exc_name = type(exc).__name__ if exc is not None else None
    final_message = message or (str(exc).strip() if exc is not None else "unknown runtime error")
    final_message = final_message or "unknown runtime error"

    if retryable is None:
        retryable = exc_name in _RETRYABLE_EXCEPTION_NAMES

    if error_code is None:
        suffix = exc_name or "runtime_error"
        if stage:
            error_code = f"{stage}.{suffix}"
        else:
            error_code = suffix

    return ErrorEvent(
        message=final_message,
        node=node,
        error_code=error_code,
        stage=stage,
        retryable=retryable,
        degraded=degraded,
        tool_name=tool_name,
    )


def error_event_as_finding_fields(event: ErrorEvent) -> dict[str, Any]:
    """Project a normalized error event onto common finding degradation fields."""

    return {
        "collection_status": "failed",
        "degraded": event.degraded,
        "error_code": event.error_code,
        "error_message": event.message,
    }
