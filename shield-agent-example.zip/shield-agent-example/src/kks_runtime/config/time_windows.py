from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta

from kks_runtime.config.settings import Settings, get_settings

_FMT = "%Y-%m-%d %H:%M:%S"


def _normalise_time(t: str) -> str:
    t = t.strip()
    if len(t) == 19 and t[10] == " ":
        return t
    for fmt in (
        "%Y-%m-%dT%H:%M:%S%z",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%d %H:%M:%S%z",
        "%Y-%m-%d %H:%M:%S",
    ):
        try:
            return datetime.strptime(t, fmt).strftime(_FMT)
        except ValueError:
            continue
    return t


@dataclass(frozen=True)
class AnalysisWindow:
    start_time: str
    end_time: str

    @property
    def duration_seconds(self) -> int:
        start = datetime.strptime(self.start_time, _FMT)
        end = datetime.strptime(self.end_time, _FMT)
        return int((end - start).total_seconds())


def normalize_analysis_window(
    start_time: str,
    end_time: str,
    *,
    settings: Settings | None = None,
    end_offset_seconds: int | None = None,
) -> AnalysisWindow:
    """Normalize an alert/investigation window and apply configured end offset."""

    s = settings or get_settings()
    offset = s.alert_end_offset_seconds if end_offset_seconds is None else end_offset_seconds

    start_dt = datetime.strptime(_normalise_time(start_time), _FMT)
    end_dt = datetime.strptime(_normalise_time(end_time), _FMT) - timedelta(seconds=offset)
    if end_dt < start_dt:
        raise ValueError("analysis_end must not be earlier than analysis_start")

    return AnalysisWindow(
        start_time=start_dt.strftime(_FMT),
        end_time=end_dt.strftime(_FMT),
    )


def previous_window(start_time: str, end_time: str) -> AnalysisWindow:
    """Return the immediately preceding window with the same duration."""

    current = normalize_analysis_window(start_time, end_time, end_offset_seconds=0)
    duration = timedelta(seconds=current.duration_seconds)
    current_start = datetime.strptime(current.start_time, _FMT)
    previous_end = current_start
    previous_start = previous_end - duration
    return AnalysisWindow(
        start_time=previous_start.strftime(_FMT),
        end_time=previous_end.strftime(_FMT),
    )


def shift_window(start_time: str, end_time: str, *, delta: timedelta) -> AnalysisWindow:
    """Shift a normalized window by a fixed timedelta."""

    current = normalize_analysis_window(start_time, end_time, end_offset_seconds=0)
    current_start = datetime.strptime(current.start_time, _FMT)
    current_end = datetime.strptime(current.end_time, _FMT)
    return AnalysisWindow(
        start_time=(current_start + delta).strftime(_FMT),
        end_time=(current_end + delta).strftime(_FMT),
    )
