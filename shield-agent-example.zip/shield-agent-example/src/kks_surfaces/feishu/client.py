"""Minimal Feishu API client for webhook-adjacent persistence paths."""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Literal
from uuid import uuid4

import httpx

logger = logging.getLogger(__name__)

TableType = Literal["alert", "chat"]


@dataclass(frozen=True)
class FeishuTableConfig:
    """Configuration for one Feishu bitable table."""

    app_token: str
    table_id: str


class FeishuClient:
    """Thin Feishu surface client using direct HTTP APIs."""

    def __init__(
        self,
        *,
        app_id: str,
        app_secret: str,
        alert_table: FeishuTableConfig | None = None,
        chat_table: FeishuTableConfig | None = None,
        request_timeout: float = 10.0,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        self._app_id = app_id
        self._app_secret = app_secret
        self._alert_table = alert_table
        self._chat_table = chat_table
        self._request_timeout = request_timeout
        self._http_client = http_client
        self._tenant_access_token: str | None = None
        self._tenant_access_token_expires_at: float = 0.0
        self._resolved_app_tokens: dict[str, str] = {}

    @classmethod
    def from_settings(
        cls,
        settings: Any,
        *,
        http_client: httpx.AsyncClient | None = None,
    ) -> "FeishuClient":
        alert_table = None
        if settings.feishu_alert_table_app_token and settings.feishu_alert_table_id:
            alert_table = FeishuTableConfig(
                app_token=settings.feishu_alert_table_app_token,
                table_id=settings.feishu_alert_table_id,
            )

        chat_table = None
        if settings.feishu_chat_table_app_token and settings.feishu_chat_table_id:
            chat_table = FeishuTableConfig(
                app_token=settings.feishu_chat_table_app_token,
                table_id=settings.feishu_chat_table_id,
            )

        return cls(
            app_id=settings.feishu_app_id,
            app_secret=settings.feishu_app_secret,
            alert_table=alert_table,
            chat_table=chat_table,
            request_timeout=float(settings.feishu_request_timeout),
            http_client=http_client,
        )

    def enabled_for(self, table_type: TableType) -> bool:
        return self._table_config(table_type) is not None and bool(self._app_id and self._app_secret)

    async def save_alert_analysis(
        self,
        *,
        alert_time: str,
        alert_name: str,
        alert_entity: str,
        analysis_question: str,
        ai_analysis_result: str,
    ) -> str | None:
        """Persist one alert analysis record into the Feishu alert table."""

        fields = {
            "告警实体": alert_entity,
            "告警时间": _parse_time_to_timestamp(alert_time),
            "告警名称": alert_name,
            "分析问题": analysis_question,
            "AI分析结果": ai_analysis_result,
        }
        return await self.table_insert_record(fields, table_type="alert")

    async def save_chat_log(
        self,
        *,
        user_id: str,
        question: str,
        answer: str | None,
        node_info: dict[str, Any] | None = None,
        server_info: dict[str, Any] | None = None,
    ) -> str | None:
        """Persist one chat exchange into the Feishu chat table."""

        record_id = await self.table_insert_record(
            {"用户ID": user_id, "问题": question},
            table_type="chat",
        )
        if not record_id:
            return None

        await self.table_update_record(
            record_id,
            {
                "回答": answer or "",
                "节点信息": _json_text(node_info),
                "网站信息": _json_text(server_info),
            },
            table_type="chat",
        )
        return record_id

    async def table_insert_record(self, row_data: dict[str, Any], *, table_type: TableType) -> str | None:
        """Insert one record into the configured Feishu bitable table."""

        table = self._table_config(table_type)
        if table is None:
            logger.info("Feishu %s table not configured; skipping insert", table_type)
            return None

        app_token = await self._resolve_app_token(table.app_token)
        if not app_token:
            return None

        response = await self._request(
            "POST",
            f"https://open.feishu.cn/open-apis/bitable/v1/apps/{app_token}/tables/{table.table_id}/records",
            params={"client_token": str(uuid4())},
            json={"fields": row_data},
        )
        if not response:
            return None
        return response.get("data", {}).get("record", {}).get("record_id")

    async def table_update_record(
        self,
        record_id: str,
        row_data: dict[str, Any],
        *,
        table_type: TableType,
    ) -> bool:
        """Update one existing record in the configured Feishu bitable table."""

        table = self._table_config(table_type)
        if table is None:
            logger.info("Feishu %s table not configured; skipping update", table_type)
            return False

        app_token = await self._resolve_app_token(table.app_token)
        if not app_token:
            return False

        response = await self._request(
            "PUT",
            f"https://open.feishu.cn/open-apis/bitable/v1/apps/{app_token}/tables/{table.table_id}/records/{record_id}",
            json={"fields": row_data},
        )
        return response is not None

    async def _resolve_app_token(self, token: str) -> str | None:
        """Support both direct bitable app tokens and wiki node tokens."""

        if token.startswith("basc"):
            return token
        cached = self._resolved_app_tokens.get(token)
        if cached:
            return cached

        response = await self._request(
            "GET",
            "https://open.feishu.cn/open-apis/wiki/v2/spaces/get_node",
            params={"token": token},
        )
        if not response:
            return None

        obj_token = response.get("data", {}).get("node", {}).get("obj_token")
        if isinstance(obj_token, str) and obj_token:
            self._resolved_app_tokens[token] = obj_token
            return obj_token

        logger.warning("Feishu wiki token resolution returned no obj_token")
        return None

    async def _get_tenant_access_token(self) -> str | None:
        now = time.monotonic()
        if self._tenant_access_token and now < self._tenant_access_token_expires_at:
            return self._tenant_access_token

        response = await self._raw_request(
            "POST",
            "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
            headers={"Content-Type": "application/json"},
            json={"app_id": self._app_id, "app_secret": self._app_secret},
        )
        if response is None:
            return None

        try:
            payload = response.json()
        except ValueError:
            logger.warning("Feishu auth returned non-JSON response")
            return None

        if payload.get("code") != 0:
            logger.warning("Feishu auth failed: %s", payload)
            return None

        token = payload.get("tenant_access_token")
        expire = int(payload.get("expire", 7200))
        if not isinstance(token, str) or not token:
            return None

        self._tenant_access_token = token
        self._tenant_access_token_expires_at = now + max(expire - 200, 60)
        return token

    async def _request(
        self,
        method: str,
        url: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        token = await self._get_tenant_access_token()
        if not token:
            logger.info("Feishu tenant token unavailable; skipping request to %s", url)
            return None

        response = await self._raw_request(
            method,
            url,
            params=params,
            json=json,
            headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        )
        if response is None:
            return None

        try:
            payload = response.json()
        except ValueError:
            logger.warning("Feishu API returned non-JSON response for %s", url)
            return None

        if payload.get("code") != 0:
            logger.warning("Feishu API failed for %s: %s", url, payload)
            return None
        return payload

    async def _raw_request(
        self,
        method: str,
        url: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> httpx.Response | None:
        client = self._http_client
        owns_client = client is None
        if client is None:
            client = httpx.AsyncClient(timeout=self._request_timeout)

        try:
            response = await client.request(method, url, params=params, json=json, headers=headers)
            response.raise_for_status()
            return response
        except httpx.HTTPError:
            logger.exception("Feishu HTTP request failed for %s %s", method, url)
            return None
        finally:
            if owns_client:
                await client.aclose()

    def _table_config(self, table_type: TableType) -> FeishuTableConfig | None:
        if table_type == "alert":
            return self._alert_table
        if table_type == "chat":
            return self._chat_table
        return None


def _json_text(value: dict[str, Any] | None) -> str:
    if value is None:
        return ""
    return json.dumps(value, ensure_ascii=False, indent=2)


def _parse_time_to_timestamp(value: str) -> int:
    try:
        normalized = value.replace("Z", "+00:00")
        return int(datetime.fromisoformat(normalized).timestamp() * 1000)
    except ValueError:
        return int(time.time() * 1000)
