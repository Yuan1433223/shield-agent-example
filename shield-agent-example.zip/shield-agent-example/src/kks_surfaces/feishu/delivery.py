"""
Feishu robot delivery adapter.

Translates `InvestigationReport` into a Feishu robot webhook payload using a
simple interactive card, or a template card when a template ID is configured.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import httpx

from kks_security.schemas.report import InvestigationReport

if TYPE_CHECKING:
    from kks_surfaces.webhook.schemas import GrafanaAlert

_STATUS_EMOJI = {
    "normal": "OK",
    "warning": "WARN",
    "critical": "CRIT",
}


def report_to_feishu_payload(report: InvestigationReport, entity: str) -> dict:
    """
    Build a Feishu interactive card payload from an `InvestigationReport`.

    Returns a dict suitable for POST to a Feishu robot webhook URL.
    """

    status = report.alert_status or "warning"
    emoji = _STATUS_EMOJI.get(status, "INFO")
    title = f"{emoji} Investigation: {entity} [{status.upper()}]"

    lines: list[str] = []

    if report.summary:
        lines += [f"**Summary**\n{report.summary}", ""]

    dimensions = [
        ("Performance", report.performance_conclusion, report.performance_has_issue),
        ("Network", report.network_conclusion, report.network_has_issue),
        ("Security", report.security_conclusion, report.security_has_issue),
        ("Requests", report.request_conclusion, False),
    ]
    for label, conclusion, has_issue in dimensions:
        if conclusion and conclusion != "[requires analysis]":
            indicator = "ISSUE" if has_issue else "OK"
            lines.append(f"**{label}** {indicator}: {conclusion}")

    investigation_lines: list[str] = []
    if report.abnormal_object:
        investigation_lines.append(f"- Object: {report.abnormal_object}")
    if report.status_origin and report.status_origin != "unknown":
        investigation_lines.append(f"- Status Origin: {report.status_origin}")
    if report.temporal_relation and report.temporal_relation != "unknown":
        investigation_lines.append(f"- Temporal Relation: {report.temporal_relation}")
    if report.classification and report.classification != "unknown":
        investigation_lines.append(f"- Classification: {report.classification}")
    if report.evidence_tags:
        investigation_lines.append(f"- Evidence Tags: {', '.join(report.evidence_tags)}")
    if report.mitigation_rationale and report.mitigation_rationale != "[requires analysis]":
        investigation_lines.append(f"- Mitigation Rationale: {report.mitigation_rationale}")
    if investigation_lines:
        lines += ["", "**Investigation**", *investigation_lines, ""]

    if report.root_cause and report.root_cause != "[requires analysis]":
        lines += [f"**Root Cause**\n{report.root_cause}", ""]

    if report.recommendations and report.recommendations != "[requires analysis]":
        lines += [f"**Recommendations**\n{report.recommendations}", ""]

    body_text = "\n".join(lines).strip()

    return {
        "msg_type": "interactive",
        "card": {
            "header": {
                "title": {"tag": "plain_text", "content": title},
                "template": _card_color(status),
            },
            "elements": [{"tag": "markdown", "content": body_text}],
        },
    }


def report_to_feishu_template_payload(
    report: InvestigationReport,
    entity: str,
    *,
    alert_meta: dict,
    template_id: str,
    template_version: str,
    processed_url: str = "",
) -> dict:
    """
    Build a Feishu template card payload from an `InvestigationReport`.

    `alert_meta` must contain: alertnames (str), starts_at (str),
    firing_count (int), question (str), entity_type (str).
    """

    perf = report.performance_metrics
    sec = report.security_metrics
    req = report.request_metrics

    template_variable = {
        "alert_title": alert_meta.get("alertnames", entity),
        "alert_entity": entity,
        "alert_time": alert_meta.get("starts_at", ""),
        "alert_count": alert_meta.get("firing_count", 1),
        "entity_type": alert_meta.get("entity_type", "domain"),
        "question": alert_meta.get("question", ""),
        "performance_conclusion": _safe_str(report.performance_conclusion),
        "cpu_usage": _safe_str(perf.cpu_usage if perf else None),
        "memory_usage": _safe_str(perf.memory_usage if perf else None),
        "network_conclusion": _safe_str(report.network_conclusion),
        "security_conclusion": _safe_str(report.security_conclusion),
        "has_cc_attack": bool(sec.has_cc_attack) if sec and sec.has_cc_attack is not None else False,
        "has_ddos_attack": bool(sec.has_ddos_attack) if sec and sec.has_ddos_attack is not None else False,
        "request_conclusion": _safe_str(report.request_conclusion),
        "status_code": _safe_str(req.status_code_distribution if req else None),
        "ai_name": "claude",
        "processed_url": processed_url or "",
    }

    return {
        "msg_type": "interactive",
        "card": {
            "type": "template",
            "data": {
                "template_id": template_id,
                "template_version_name": template_version,
                "template_variable": template_variable,
            },
        },
    }


def _safe_str(value: object) -> str:
    if value is None or str(value) in {"[requires analysis]", "unknown"}:
        return ""
    return str(value)


def _card_color(status: str) -> str:
    return {"normal": "green", "warning": "yellow", "critical": "red"}.get(status, "blue")


def _fmt_starts_at(raw: str) -> str:
    return raw.replace("T", " ").rstrip("Z")


def build_firing_alert_payload(
    entity: str,
    firing_alerts: list[GrafanaAlert],
    *,
    analysis_started: bool = False,
) -> dict:
    """
    Build an immediate alert notification card (sent before AI analysis begins).

    Mirrors KKShieldHelper-main Stage-1 card: lists every firing alert with
    its trigger time and panel URL, then optionally appends an "AI analysing"
    indicator when analysis_started=True.
    """
    lines: list[str] = [f"**实体：** {entity}", "**触发告警：**"]
    for a in firing_alerts:
        name = a.labels.get("alertname", "未知告警")
        ts = _fmt_starts_at(a.startsAt) if a.startsAt else ""
        line = f"- **{name}**" + (f"  `{ts}`" if ts else "")
        if a.panelURL:
            line += f"  [查看面板]({a.panelURL})"
        lines.append(line)

    if analysis_started:
        lines += ["", "⏳ 正在进行 AI 智能巡检，请稍候..."]

    return {
        "msg_type": "interactive",
        "card": {
            "header": {
                "title": {"tag": "plain_text", "content": f"🔴 告警通知 · {entity}"},
                "template": "red",
            },
            "elements": [{"tag": "markdown", "content": "\n".join(lines)}],
        },
    }


async def send_payload_to_feishu(
    webhook_url: str,
    payload: dict,
    *,
    http_client: httpx.AsyncClient | None = None,
) -> bool:
    """POST an arbitrary Feishu card payload to a robot webhook URL."""
    owns_client = http_client is None
    client = http_client or httpx.AsyncClient(timeout=5)
    try:
        response = await client.post(webhook_url, json=payload)
        if response.status_code != 200:
            return False
        try:
            body = response.json()
        except ValueError:
            return True
        return body.get("code", 0) == 0
    finally:
        if owns_client:
            await client.aclose()


async def send_report_to_feishu(
    webhook_url: str,
    report: InvestigationReport,
    entity: str,
    *,
    alert_meta: dict | None = None,
    template_id: str = "",
    template_version: str = "",
    processed_url: str = "",
    http_client: httpx.AsyncClient | None = None,
) -> bool:
    """
    POST an `InvestigationReport` as a Feishu card to the given webhook URL.

    Uses the template card path when `template_id` is set and `alert_meta` is
    provided; falls back to the markdown interactive card otherwise.

    Returns True on application-level success.
    """
    if template_id and alert_meta is not None:
        payload = report_to_feishu_template_payload(
            report,
            entity,
            alert_meta=alert_meta,
            template_id=template_id,
            template_version=template_version,
            processed_url=processed_url,
        )
    else:
        payload = report_to_feishu_payload(report, entity)

    return await send_payload_to_feishu(webhook_url, payload, http_client=http_client)

