"""Helpers for translating investigation artifacts into Feishu-friendly payloads."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from kks_security.schemas.report import InvestigationReport, PerformanceMetrics, SecurityMetrics


def report_from_artifact(artifact: Mapping[str, Any]) -> InvestigationReport:
    """Extract the full structured report from an investigation artifact."""

    report_payload = artifact.get("report")
    if isinstance(report_payload, Mapping) and report_payload:
        report = InvestigationReport.model_validate(dict(report_payload))
    else:
        recommendations = artifact.get("recommendations")
        recommendation_text = ""
        if isinstance(recommendations, list):
            recommendation_text = "\n".join(str(item) for item in recommendations if item)
        report = InvestigationReport(
            summary=str(artifact.get("summary") or "[requires analysis]"),
            recommendations=recommendation_text or None,
            alert_status=_risk_to_alert_status(artifact.get("risk_level")),
        )

    findings = artifact.get("findings")
    if isinstance(findings, Mapping):
        _backfill_report_metrics(report, findings)

    return report


def _backfill_report_metrics(report: InvestigationReport, findings: Mapping[str, Any]) -> None:
    """Populate typed metrics fields from raw findings when the reporter LLM left them empty."""

    machine = findings.get("machine")
    if report.performance_metrics is None and isinstance(machine, Mapping):
        cpu_pct = machine.get("cpu_pct")
        memory_pct = machine.get("memory_pct")
        tcp_established = machine.get("tcp_established")
        report.performance_metrics = PerformanceMetrics(
            cpu_usage=f"{cpu_pct * 100:.1f}%" if isinstance(cpu_pct, (int, float)) else "unknown",
            memory_usage=f"{memory_pct * 100:.1f}%" if isinstance(memory_pct, (int, float)) else "unknown",
            tcp_connections=str(tcp_established) if tcp_established is not None else "unknown",
        )

    security = findings.get("security")
    if report.security_metrics is None and isinstance(security, Mapping):
        report.security_metrics = SecurityMetrics(
            has_cc_attack=security.get("cc_is_under_attack"),
            has_ddos_attack=security.get("ddos_exceeds_threshold"),
        )


def build_alert_analysis_text(artifact: Mapping[str, Any]) -> str:
    """Render a stable multi-section text block for Feishu bitable persistence."""

    report = report_from_artifact(artifact)
    findings = artifact.get("findings")
    investigation = findings.get("investigation") if isinstance(findings, Mapping) else None
    strategy = findings.get("strategy") if isinstance(findings, Mapping) else None

    sections: list[str] = []

    if report.summary and report.summary != "[requires analysis]":
        sections.append(f"【核心结论】\n{report.summary}")

    if isinstance(investigation, Mapping):
        lines = _non_empty_lines(
            ("异常对象", investigation.get("abnormal_object")),
            ("状态来源", investigation.get("status_origin")),
            ("时序关系", investigation.get("temporal_relation")),
            ("攻击分类", investigation.get("classification")),
            ("可能原因", investigation.get("likely_cause")),
            ("证据标签", _format_list(investigation.get("evidence_tags"))),
            ("处置标签", _format_list(investigation.get("mitigation_tags"))),
            ("判定依据", investigation.get("rationale")),
        )
        if lines:
            sections.append("【调查判定】\n" + "\n".join(lines))

    dimension_lines = _non_empty_lines(
        ("性能结论", report.performance_conclusion),
        ("网络结论", report.network_conclusion),
        ("安全结论", report.security_conclusion),
        ("请求结论", report.request_conclusion),
    )
    if dimension_lines:
        sections.append("【分维度结论】\n" + "\n".join(dimension_lines))

    if report.root_cause and report.root_cause != "[requires analysis]":
        sections.append(f"【根因分析】\n{report.root_cause}")

    action_lines = _strategy_lines(strategy)
    if action_lines:
        sections.append("【处置建议】\n" + "\n".join(action_lines))
    elif report.recommendations and report.recommendations != "[requires analysis]":
        sections.append(f"【处置建议】\n{report.recommendations}")

    if artifact.get("degraded") is True:
        sections.append("【运行状态】\n本次调查以降级模式完成，请结合结构化 findings 复核。")

    return "\n\n".join(section for section in sections if section).strip()


def _risk_to_alert_status(risk_level: Any) -> str:
    return {"low": "normal", "medium": "warning", "high": "critical", "critical": "critical"}.get(
        str(risk_level or "medium"), "warning"
    )


def _strategy_lines(strategy: Any) -> list[str]:
    if not isinstance(strategy, Mapping):
        return []
    actions = strategy.get("recommended_actions")
    if not isinstance(actions, list):
        return []

    lines: list[str] = []
    for idx, action in enumerate(actions[:3], start=1):
        if not isinstance(action, Mapping):
            continue
        title = str(action.get("title") or "").strip()
        rationale = str(action.get("rationale") or "").strip()
        if not title:
            continue
        lines.append(f"{idx}. {title}" if not rationale else f"{idx}. {title} | {rationale}")
    return lines


def _non_empty_lines(*pairs: tuple[str, Any]) -> list[str]:
    lines: list[str] = []
    for label, value in pairs:
        text = _normalize_value(value)
        if text:
            lines.append(f"{label}：{text}")
    return lines


def _format_list(value: Any) -> str:
    if isinstance(value, list):
        items = [str(item).strip() for item in value if str(item).strip()]
        return "、".join(items)
    return _normalize_value(value)


def _normalize_value(value: Any) -> str:
    if value is None:
        return ""
    text = str(value).strip()
    if not text or text == "[requires analysis]":
        return ""
    return text
