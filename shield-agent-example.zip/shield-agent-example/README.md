# kks-next

基于 LangGraph 构建的 agentic 调查运行时，优化 KKShieldHelper-main。

## 架构

三层结构，职责严格隔离：

```
kks_runtime    — LangGraph 运行时、会话生命周期、状态、事件、checkpoint、审批、artifact
kks_security   — 安全领域工具、ES/Prometheus/WAF/GF 适配器、采集器、playbook、策略、RAG
kks_surfaces   — FastAPI 接口、webhook、飞书推送、Web UI（薄层，无业务逻辑）
```

## 调查图流程

```
START → asset_resolution → supervisor → [log_detective / machine_check / security_guard
       / causality_judge / strategy_mapper] → approval_gate? → reporter → END
```

- supervisor 根据 target 类型（IP / 域名）做能力约束后分发
- machine_check / security_guard 通过 `Send` 做资产级 fan-out，结果先写 `asset_findings`，再 rollup 到顶层 `findings`
- approval_gate 由 `EvidencePolicy.requires_approval()` 决定是否插入
- supervisor 最多重试 3 次；支持 checkpoint 恢复

## 模型抽象

业务代码请求 profile，不直接绑定 SDK：

| profile | 用途 |
|---|---|
| `fast_classifier` | 快速分类 |
| `tool_reasoner` | 工具调用推理 |
| `structured_extractor` | 结构化提取 |
| `report_writer` | 报告生成 |
| `long_context_analyst` | 长上下文分析 |
| `local_offline_model` | 本地离线模型 |

## 快速开始

```bash
# 依赖管理用 uv
uv sync

# 复制环境变量
cp .env.example .env
# 按需填写 ES / Milvus / MongoDB / Anthropic API Key 等

# 启动 API 服务
kks-serve
# 或
uv run uvicorn kks_surfaces.api.app:app --reload
```

## 开发

```bash
# 运行测试
uv run pytest

# lint / format
uv run ruff check .
uv run ruff format .

# 类型检查
uv run mypy src/
```

测试分四类：`tests/unit/`、`tests/integration/`、`tests/replay/`（事件回放）、`tests/evals/`（跨模型评估）。

## 关键约定

- 适配器必须实现 `aclose()` / `__aenter__` / `__aexit__`，禁止模块级实例化
- 禁止在图节点内写 HTTP / webhook / 飞书逻辑
- 禁止 asset 并行 worker 直接写顶层 finding key
- 禁止将 LangGraph 框架代码复制进本仓库
- 证据阈值必须在代码策略中定义，不能只藏在 prompt 里

## 与旧版关系

`KKShieldHelper-main` 是唯一的 donor 仓库，选择性迁移采集器、适配器、报告 schema、playbook 逻辑。不迁移旧图的连线结构。
